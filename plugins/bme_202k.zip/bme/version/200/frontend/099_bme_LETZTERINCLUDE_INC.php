<?php
if (0 && $oPlugin->oPluginEinstellungAssoc_arr['bme_search_active'] == 'Y' || $oPlugin->oPluginEinstellungAssoc_arr['bme_search_active'] == 'J'){
	require_once dirname(__FILE__) . '/inc/class.bme_search.php';
	global $smarty;

	$smarty->clear_assign('nMaxAnzahlArtikel');

	$bme_adToVersion = '_bme_2_e';
	$smarty->assign('nTemplateVersion', $smarty->get_template_vars('nTemplateVersion') . $bme_adToVersion);
}

?>