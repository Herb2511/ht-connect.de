<?php

if (isset($_GET['bme']) && $_GET['bme'] = 'true') {
	$ch = curl_init( 'https://suche.bm-suche.de/bm-suche.de' ); 
	curl_setopt( $ch, CURLOPT_POST, true ); 
	curl_setopt( $ch, CURLOPT_POSTFIELDS, $_POST ); 

	curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, true ); 
	//curl_setopt( $ch, CURLOPT_HEADER, true ); 
	curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true ); 
	curl_setopt($ch,CURLOPT_HTTPHEADER,array('Origin: ' . URL_SHOP)); 
	curl_setopt($ch, CURLOPT_USERAGENT, $_GET['user_agent'] ? $_GET['user_agent'] : $_SERVER['HTTP_USER_AGENT'] ); 

	$response = curl_exec($ch); 
	die($response); 
	
}