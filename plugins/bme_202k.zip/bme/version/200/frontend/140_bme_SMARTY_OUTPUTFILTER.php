<?php
require_once dirname(__FILE__) . '/inc/class.bme_search.php';
//echo $smarty->get_template_vars("Einstellungen")["global"]["wartungsmodus_aktiviert"] . "<hr>";
//echo  $smarty->get_template_vars("bAdminWartungsmodus"); die();
if ($smarty->get_template_vars("Einstellungen")["global"]["wartungsmodus_aktiviert"] != "Y" || $smarty->get_template_vars("bAdminWartungsmodus") == "1"){
	
	if ($oPlugin->oPluginEinstellungAssoc_arr['bme_search_active'] == 'Y' || $oPlugin->oPluginEinstellungAssoc_arr['bme_search_active'] == 'J'){
	//echo "<pre>";print_r(get_defined_vars());die();
		//if Hook 161
		
		$smarty->assign('bme', bme_search::getInstance()->getSmartyBME($oPlugin));

		$smarty->assign('bme_resultTemplateArticle', bme_search::getInstance()->getSmartyEmptyArticle());

		pq('.ac_input')->removeClass('ac_input')->addClass('bme_input');

		switch($oPlugin->oPluginEinstellungAssoc_arr['bme_template_name']){
			case 'hypnos':
				pq('#outer_wrapper')->after(bme_search::getInstance()->getPageTemplate($smarty, $oPlugin));
				pq('#bme_search')->addClass(pq('#outer_wrapper')->attr("class"));
				if (bme_search::getInstance()->getSearchType() == 'page'){
					pq('#outer_wrapper ')->remove();
				}
				break;
			default:
			case "salepix-avia":
			case "semaf":
			case 'evo':
				pq('#content')->after(bme_search::getInstance()->getPageTemplate($smarty, $oPlugin));
				pq('#bme_search')->addClass(pq('#content')->attr("class"));
				if (bme_search::getInstance()->getSearchType() == 'page'){
					pq('#content')->remove();
				}
				break;
		}


		pq('head')->append(bme_search::getInstance()->getCSS($oPlugin));


		if(bme_search::getInstance()->getSearchType() == 'page'){

			pq('.bme_input')->val(bme_search::getInstance()->getQuery());
			pq('body')->addClass('bme_opened bme_searchPage');
			
			//TODO???
			//$smarty->tpl_vars['Suchergebnisse']->value->Suchspecialauswahl = array();

		}


	}	
}	
?>