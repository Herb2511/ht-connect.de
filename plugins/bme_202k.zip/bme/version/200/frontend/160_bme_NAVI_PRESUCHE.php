<?php
require_once dirname(__FILE__) . '/inc/class.bme_search.php';
$args_arr['cValue'] = preg_replace("/^[-]+$/", "", $args_arr['cValue']);
//print_r($args_arr);die();
$args_arr['bExtendedJTLSearch'] = bme_search::getInstance()->getStatus();
$_SESSION['bExtendedJTLSearch'] = $args_arr['bExtendedJTLSearch'];
?>