<?php

//Status?
if (1) {
	$args_arr['bExtendedJTLSearch'] = true;

	class JtlSearch {

		public static function getFilter($cParamAssoc_arr) {
			$cFilter_arr = [];
//			for ($i = 0; $i < 20; $i++) {
//				if (isset($cParamAssoc_arr["fq{$i}"])) {
//					$cFilter_arr[] = $cParamAssoc_arr["fq{$i}"];
//				}
//			}

			return $cFilter_arr;
		}

		public static function buildFilterShopURL($cFilter_arr)
		{

			return '';
		}

	}

} else {
	$args_arr['bExtendedJTLSearch'] = false;
}