<?php
//Status?
echo "<pre>";
print_r($args_arr);
echo "</pre>";
$items = array("62795", "156906","156909");
$itemARR = array();
foreach ($items as $elem){
//  $article = new stdClass();
$article = "";
    $article->nID = $elem;
    
      $itemARR[] = $article;
//      print_r($itemARR);
      }
      
      
      
      $result = new stdClass();
      $result->oSearch->oItem_arr = $itemARR;
      $args_arr['oExtendedJTLSearchResponse'] = $result;
      
      
      echo "<pre>";
      print_r($args_arr);
      echo "</pre>";
 //     die("???");
     