<?php
class bme_index {
	private $fh;
	private $catDataARR;
	private $pw;
	private $oPlugin;
	private $pictARR;
	private $priceData;
	private $varKombi;
	private $updateType = 'full';
	private $updateIDs = array();
	private $kategorieRabattARR = array();
	private $tkundengruppeARR = array();
	private $JTL_imageSettings = array();
	private $JTL_globalSettings = array();
	
	private $kategorieSichtbarkeit = array();
	private $artikelSichtbarkeit = array();

	public function __construct(&$oPlugin) {
		$this->oPlugin = $oPlugin;
		Session::getInstance();
	}
	

	private function checkPW() {
		if (key_exists('bme_sync_passphrase', $this->oPlugin->oPluginEinstellungAssoc_arr)) {
			$this->pw = $this->oPlugin->oPluginEinstellungAssoc_arr['bme_sync_passphrase'];
		} else {
			$this->pw = $this->oPlugin->oPluginEinstellungAssoc_arr['bme_passphrase'];
		}

		if (isset($_POST["pw"]) && strlen(trim($_POST["pw"])) > 8 && trim($_POST["pw"]) == trim($this->pw)) {
			return true;
		}

		return false;
	}

	public function getCSV($type = "CSV_Full") {
		if (!$this->checkPW()) {
			return false;
		}

		$this->varKombi = 'all';
		if (isset($_POST["varkombi"]) && strlen(trim($_POST["varkombi"])) > 2) {
			switch ($_POST["varkombi"]) {
				case "parents":
				case "childs":
					$this->varKombi = $_POST["varkombi"];
					break;
				case "all":
				default:
					break;
			}
		}

		//Check MaxCount if inc Update and get kArtikelIDs
		$maxCount = 3000;

		$kArtikelARR = array();
		if ($type == "CSV_Incremental") {
			$anzahl = 0;
			
			$sql = "SELECT kArtikel, type FROM xplugin_bme_update_article AS A";
			$result = Shop::DB()->executeQuery($sql, 10);
			while ($elem = $result->fetchObject()) {
				if ($elem->type == 'delete') {
					if (is_numeric($elem->kArtikel)) {
						$anzahl++;
						$kArtikelDeleteARR[] = $elem->kArtikel;
					}
				} else {
					if (is_numeric($elem->kArtikel)) {
						$anzahl++;
						$kArtikelARR[] = $elem->kArtikel;
					}
				}
			}
			if ($anzahl == 0) {
				die('nothingToDo');
			}
			
			$sqlARR[] = "SELECT B.kArtikel, type FROM xplugin_bme_update_article AS A left JOIN tartikel AS B ON A.kArtikel = B.kArtikel";
			$sqlARR[] = "SELECT C.kArtikel, type FROM xplugin_bme_update_article AS A LEFT JOIN tartikel AS C ON A.kArtikel = C.kVaterArtikel WHERE C.kArtikel > 0";
			$sqlARR[] = "SELECT B.kArtikel, type FROM xplugin_bme_update_article AS A left JOIN tartikel AS B ON A.kArtikel = B.kArtikel left JOIN tartikel AS D ON B.kVaterArtikel = D.kArtikel AND B.kVaterArtikel > 0 WHERE B.kArtikel > 0";
			$sqlARR[] = "SELECT B.kArtikel, type FROM xplugin_bme_update_article AS A left JOIN tartikel AS B ON A.kArtikel = B.kArtikel left JOIN tartikel AS E ON B.kVaterArtikel = E.kVaterArtikel AND B.kVaterArtikel > 0  WHERE B.kArtikel > 0";

			
			foreach ($sqlARR as $sql){
				$result = Shop::DB()->executeQuery($sql, 10);
				while ($elem = $result->fetchObject()) {
					if ($elem->type == 'delete') {
						if (is_numeric($elem->kArtikel)) {
							$anzahl++;
							$kArtikelDeleteARR[] = $elem->kArtikel;
						}
					} else {
						if (is_numeric($elem->kArtikel)) {
							$anzahl++;
							$kArtikelARR[] = $elem->kArtikel;
						}
					}
				}

				if ($anzahl > $maxCount) {
					die("changeToFullUpdate");
				}
			}
			
			if ($anzahl == 0) {
				die('nothingToDo');
			} elseif ($anzahl > $maxCount) {
				die("changeToFullUpdate");
			}

			if (count($kArtikelARR) <= 0 && count($kArtikelDeleteARR) <= 0) {
				return;
			}
		}

		$sql = "SELECT * FROM tkategoriesichtbarkeit";
		$result = Shop::DB()->executeQuery($sql, 10);
		while ($elem = $result->fetchObject()) {
			$this->kategorieSichtbarkeit[$elem->kKategorie][] = [$elem->kKundengruppe];
		}

		$sql = "SELECT * FROM tartikelsichtbarkeit";
		$result = Shop::DB()->executeQuery($sql, 10);
		while ($elem = $result->fetchObject()) {
			$this->artikelSichtbarkeit[$elem->kArtikel][$elem->kKundengruppe] = true;
		}
		
		//tkategoriekundengruppe => KategorieRabatt
		$sql = "select
			B.kArtikel
			, A.fRabatt
			, kKundengruppe
			FROM tkategoriekundengruppe AS A
			LEFT JOIN tkategorieartikel AS B ON A.kKategorie = B.kKategorie";

		if (count($kArtikelARR) > 0) {
			$sql .= ' WHERE B.kArtikel IN (' . implode(",", $kArtikelARR) . ') ';
		}

		$result = Shop::DB()->executeQuery($sql, 10);
		while ($elem = $result->fetchObject()) {
			$this->kategorieRabattARR[$elem->kArtikel][$elem->kKundengruppe] = $elem->fRabatt;
		}

		//tkundengruppe => Rabatt auf Kundengruppe, netto/brutto
		$sql = "SELECT
				kKundengruppe
				, fRabatt
				, nNettoPreise
				FROM tkundengruppe";

		$result = Shop::DB()->executeQuery($sql, 10);
		while ($elem = $result->fetchObject()) {
			$this->tkundengruppeARR[$elem->kKundengruppe]['fRabatt'] = $elem->fRabatt;
			$this->tkundengruppeARR[$elem->kKundengruppe]['nNettoPreise'] = $elem->nNettoPreise;
		}

		$this->JTL_imageSettings = Shop::getSettings(CONF_BILDER);

		$headerARR[] = 'kArtikel';
		$headerARR[] = 'cName';
		$headerARR[] = 'cArtNr';
		$headerARR[] = 'cHAN';
		$headerARR[] = 'cBarcode';
		$headerARR[] = 'cHersteller';
		$headerARR[] = 'kHersteller';
		$headerARR[] = 'cSeo';
		$headerARR[] = 'image';
		$headerARR[] = 'cISO';
		$headerARR[] = 'cSuchbegriffe';
		$headerARR[] = 'topartikel';
		$headerARR[] = 'verfuegbarkeit';
		$headerARR[] = 'bestseller';
		$headerARR[] = 'dErstellt';
		$headerARR[] = 'cBeschreibung';
		$headerARR[] = 'cKurzBeschreibung';
		$headerARR[] = 'catIDs';
		$headerARR[] = 'catARR';
		$headerARR[] = 'Merkmal';
		$headerARR[] = 'price';
		$headerARR[] = 'varKombi';
		$headerARR[] = 'fLagerbestand';
		$headerARR[] = 'cISBN';
		$headerARR[] = 'cASIN';
		$headerARR[] = 'artikelsichtbarkeit';
		/*
		  $headerARR[] = 'childNames';
		  $headerARR[] = 'childArtnr';
		  $headerARR[] = 'childHAN';
		 */

		$bme_tmpfname = tempnam(sys_get_temp_dir(), 'BME_');
		$this->fh = @fopen($bme_tmpfname, 'w+');
		if (!$this->fh) {
			$fallbackTmpDir = PFAD_ROOT . PFAD_COMPILEDIR;
			$bme_tmpfname = tempnam($fallbackTmpDir, 'BME_');
			$this->fh = @fopen($bme_tmpfname, 'w+');
			if (!$this->fh) {
				die('fh2 not writable: ' . $this->fh . ' - ' . $bme_tmpfname);
			}
		}

		fwrite($this->fh, '"');
		fwrite($this->fh, implode('"~"', $headerARR));
		fwrite($this->fh, '"' . PHP_EOL);

		if ($type == "CSV_Full" || count($kArtikelARR) > 0) {
			if ($type == 'CSV_Full') {
				$sql = 'DELETE FROM xplugin_bme_update_article ';
				Shop::DB()->executeQuery($sql, 3);
			}


			$sql = "SELECT
				kSprache
				, cISO
				, cShopStandard
				FROM
				tsprache
				";
			$result = Shop::DB()->executeQuery($sql, 9);

			foreach ($result as $language) {
				$this->getCatData($language);

				$sql = "SELECT
				A.kArtikel";

				if ($language['cShopStandard'] != 'Y') {
					$sql .= ', COALESCE(I.cName, A.`cName`) AS cName
				, I.cSeo
				, COALESCE(I.`cBeschreibung`, A.`cBeschreibung`) AS cBeschreibung
				, COALESCE(I.`cKurzBeschreibung`, A.`cKurzBeschreibung`) AS cKurzBeschreibung
				';
				} else {
					$sql .= ', A.cName
				, A.cSeo
				, A.`cBeschreibung`
				, A.`cKurzBeschreibung`
				';
				}


				$sql .= "					
				,  IF(A.fLagerbestand > 0, '0', IF(A.fLieferantenlagerbestand > 0, A.fLieferzeit,'')) as BME_Lieferzeit 
				, A.`cArtNr`
				, A.`cHAN`
				, A.`cBarcode`
				, A.`kHersteller`
				, A.`cTopArtikel`
				, A.`cNeu`
				, A.`dErstellt`
				, A.`cLagerBeachten`
				, A.`cLagerKleinerNull`
				, A.`cSuchbegriffe`
				, A.`kVaterArtikel`
				, A.`nIstVater`
				, A.`fLagerbestand`
				, A.`cISBN`
				, A.`cASIN`
				
					
				, B.`cName` AS cHersteller
					
				, C.`fDurchschnittsBewertung`
				
				, K.`fAnzahl` as bestseller
					
				, GROUP_CONCAT(DISTINCT D.kKategorie) as catIDs
				, GROUP_CONCAT(DISTINCT
					CONCAT (
				
						LPAD(F.nSort,3,'0'), '_'
						, COALESCE(J.cName, F.cName)
						, '_'
						, F.cTyp
						, '_'
						, E.kMerkmal
						, '=='
						, LPAD(G.nSort,3,'0')
						, '_'
						, H.cWert
						, '_'
						, E.`kMerkmalWert`
					)
			
					SEPARATOR '||'
				) AS Merkmal 
				
				, GROUP_CONCAT(
					DISTINCT CONCAT (
						L.kKundengruppe
						, '_'
						, L.fVKNetto
						, '_'
						, A.kSteuerklasse
					)
					SEPARATOR '||' 
					
				) AS priceData 
				, GROUP_CONCAT( 
					DISTINCT CONCAT (M.nNr, '__', M.cPfad) SEPARATOR '||'
				) AS imageData
				, GROUP_CONCAT( 
					DISTINCT CONCAT (O.kKundengruppe, '_', O.fNettoPreis , '_' , A.kSteuerklasse) SEPARATOR '||'
				) AS sonderpreisData	";
				/*
				  , GROUP_CONCAT(P.cName SEPARATOR ' ' ) AS childNames
				  , GROUP_CONCAT(P.`cHAN` SEPARATOR ' ' ) AS childHAN
				  , GROUP_CONCAT(P.`cArtNr` SEPARATOR ' ' ) AS childArtnr
				 */
				$sql .= " 
				FROM tartikel AS A
				LEFT JOIN thersteller AS B ON A.kHersteller = B.kHersteller
				LEFT JOIN tartikelext AS C ON A.kArtikel=C.kArtikel
				LEFT JOIN tkategorieartikel AS D ON A.kArtikel = D.kArtikel
			
				LEFT JOIN tartikelmerkmal AS E ON A.kArtikel = E.kArtikel
				LEFT JOIN tmerkmal AS F ON E.kMerkmal = F.kMerkmal
				LEFT JOIN tmerkmalwert AS G ON E.kMerkmalWert = G.kMerkmalWert
				LEFT JOIN tmerkmalwertsprache AS H ON E.kMerkmalWert = H.kMerkmalWert AND H.kSprache = " . $language['kSprache'] . " 
				LEFT JOIN tmerkmalsprache AS J ON F.kMerkmal = J.kMerkmal AND J.kSprache = " . $language['kSprache'] . " ";
				if ($language['cShopStandard'] != 'Y') {
					$sql .= 'LEFT JOIN tartikelsprache AS I ON A.kArtikel = I.kArtikel AND I.kSprache = ' . $language['kSprache'] . ' ';
				}
				$sql .= 'LEFT JOIN tbestseller AS K ON A.kArtikel = K.kArtikel 
				LEFT JOIN tpreise AS L ON A.kArtikel = L.kArtikel
				
				LEFT JOIN tartikelpict AS M ON A.kArtikel = M.kArtikel AND M.nNr < 4 
						
				LEFT JOIN tartikelsonderpreis AS N ON A.kArtikel = N.kArtikel AND (N.nIstDatum = 0 OR (N.dStart <= now() AND N.dEnde >= now())) AND
				(
				N.nIstAnzahl = 0
				OR
				(N.nAnzahl <= A.fLagerbestand)
				)
				LEFT JOIN tsonderpreise AS O ON N.kArtikelSonderpreis = O.kArtikelSonderpreis 
				LEFT JOIN tartikel AS P ON A.`kArtikel` = P.`kVaterArtikel`
						';

				$this->JTL_globalSettings = Shop::getSettings(CONF_GLOBAL);

				$separator = "WHERE ";

				//1 => alle Artikel
				//2 => nur Lager > 0
				//3 => Lager > 0 oder Ueberverkauf = Y
				switch ($this->JTL_globalSettings['global']['artikel_artikelanzeigefilter']) {
					case '2':
						$sql .= $separator . ' A.`fLagerbestand` > 0 ';
						$separator = "AND ";
						break;
					case '3':
						$sql .= $separator . ' ( A.`fLagerbestand` > 0 OR A.`cLagerBeachten` = "N" OR A.`cLagerKleinerNull` = "Y") ';
						$separator = "AND ";
						break;
					case '1':
					default:
						break;
				}

				if (count($kArtikelARR) > 0) {
					$sql .= $separator . 'A.kArtikel IN (' . implode(",", $kArtikelARR) . ') ';
					$separator = "AND ";
				}

				switch ($this->varKombi) {
					case "childs":
						$sql .= $separator . 'A.`nIstVater` = 0 ';
						$separator = "AND ";
						break;
					case "parents":
						$sql .= $separator . 'A.`kVaterArtikel` = 0 ';
						$separator = "AND ";
						break;
					case "all":
					default:
						break;
				}

				$sql .= "GROUP BY A.kArtikel ";
				//$sql .= "ORDER BY A.`nIstVater` DESC ";

				$result = Shop::DB()->executeQuery("SET SQL_BIG_SELECTS=1", 1);

				$result = Shop::DB()->executeQuery($sql, 10);

				//die($sql);
				while ($elem = $result->fetchObject()) {

					fwrite($this->fh, $this->getCSVItem($elem, $language));
				}

				if (count($kArtikelARR) > 0 ) {

						$sql = 'DELETE FROM xplugin_bme_update_article ';
						$sql .= ' WHERE ';
						$sql .= 'kArtikel IN (' . implode(",", $kArtikelARR) . ') ';
						Shop::DB()->executeQuery($sql, 3);

				}
			}
		}

		if(count($kArtikelDeleteARR) > 0){
			foreach ($kArtikelDeleteARR as $kArtikel){
				fwrite($this->fh, '"' . $kArtikel . '"~"delete"' . PHP_EOL);
			}
			$sql = 'DELETE FROM xplugin_bme_update_article ';
			$sql .= ' WHERE kArtikel IN (' . implode(",", $kArtikelDeleteARR) .') ';
			Shop::DB()->executeQuery($sql, 3);
		}

		require_once dirname(__FILE__) . '/class.bme_search.php';
		$version = bme_search::getInstance()->getVersion();
		
		fwrite($this->fh, 'EOF||' . JTL_VERSION . '||' . $version . '||' . $this->oPlugin->oPluginEinstellungAssoc_arr['bme_template_name']);
		fclose($this->fh);
		//echo "<hr>".filesize($bme_tmpfname)."<hr>";
		$bme_tmpzipfname = tempnam(sys_get_temp_dir(), 'BME_');
		$fp = @gzopen($bme_tmpzipfname, 'wb');
		//die($bme_tmpzipfname);
		if (!$fp) {
			$fallbackTmpDir = PFAD_ROOT . PFAD_COMPILEDIR;
			$bme_tmpzipfname = tempnam($fallbackTmpDir, 'BME_');
			$fp = @gzopen($bme_tmpzipfname, 'wb');
			if (!$fp) {
				die('fp not writable: ' . $fp . ' - ' . $fallbackTmpDir);
			}
		}

		// Compress the file
		if ($fp_in = fopen($bme_tmpfname, 'rb')) {
			while (!feof($fp_in)) {
				gzwrite($fp, fread($fp_in, 1024 * 512));
			}
			fclose($fp_in);
		}


		// Close the gz file and we're done
		gzclose($fp);
		//readfile($bme_tmpfname);die();
		unlink($bme_tmpfname);

		//echo "<hr>".filesize($bme_tmpzipfname)."<hr>";
		header("Content-Encoding: gzip");
		header("Content-Type: application/gzip");
		//die();
		readfile($bme_tmpzipfname);

		unlink($bme_tmpzipfname);

		return true;
	}

	private function getPictureLink(&$elem) {
		$imgARR = explode('||', $elem->imageData);

		sort($imgARR);

		$tmpData = explode('__', $imgARR[0]);
		$dbImageNr = $tmpData[0];
		$dbImageName = $tmpData[1];
		//Get first Image!
		if (count($imgARR) > 0 && strlen($dbImageName) > 5) {
			switch ($this->JTL_imageSettings["bilder"]["bilder_artikel_namen"]) {
				case 0:
					$imageName = $elem->kArtikel;
					break;
				case 1:
					$imageName = $elem->cArtNr;
					break;
				case 2:
					$imageName = empty($elem->cSeo) ? $elem->cName : $elem->cSeo;
					break;
				case 3:
					$imageName = sprintf('%s_%s', $elem->cArtNr, empty($elem->cSeo) ? $elem->cName : $elem->cSeo);
					break;
				case 4:
					$imageName = $elem->cBarcode;
					break;
			}

			$imageName = strtolower($imageName);

			$source = array(
				'.',
				' ',
				'.',
				'/',
				'ä',
				'ö',
				'ü',
				'ß',
				utf8_decode('ä'),
				utf8_decode('ö'),
				utf8_decode('ü'),
				utf8_decode('ß')
			);
			$replace = array(
				'-',
				'-',
				'-',
				'ae',
				'oe',
				'ue',
				'ss',
				'ae',
				'oe',
				'ue',
				'ss'
			);
			$imageName = str_replace($source, $replace, $imageName);

			$imageName = preg_replace('/[^a-zA-Z0-9\.\-_]/', '', $imageName);

			if ($elem->kVaterArtikel > 0) {
				$dirMD = PFAD_MEDIA_IMAGE . "product/" . $elem->kVaterArtikel . "/md";
				$imageName .= "-" . $elem->kArtikel;
			} else {
				$dirMD = PFAD_MEDIA_IMAGE . "product/" . $elem->kArtikel . "/md";
			}
			$newImage = "bilder/produkte/normal/" . $dbImageName;

			if (file_exists(PFAD_ROOT . "/" . $newImage)) {
				return $newImage;
			} else {
				$newImage = '';
				$newImage .= $dirMD . '/' . $imageName;
				if ($dbImageNr > 1) {
					$newImage .= '~' . $dbImageNr;
				}
				$newImage .= '.' . strtolower($this->JTL_imageSettings['bilder']['bilder_dateiformat']);
				return $newImage;
			}
		} else {
			return "";
		}
	}

	private function CSV_elem($elem) {
		//$elem = str_replace("~", "", $elem); //problems with images with Nr > 1
		//
		$elem = trim($elem);
		$elem = utf8_encode($elem);
		$elem = html_entity_decode($elem, ENT_COMPAT);
		$elem = addslashes($elem);
		return $elem;
	}

	private function getCSVItem($elem, $language) {
		$item = '"';
		$item .= $this->CSV_elem($elem->kArtikel) . '"~"';
		$item .= $this->CSV_elem($elem->cName) . '"~"';
		$item .= $this->CSV_elem($elem->cArtNr) . '"~"';
		$item .= $this->CSV_elem($elem->cHAN) . '"~"';
		$item .= $this->CSV_elem($elem->cBarcode) . '"~"';
		$item .= $this->CSV_elem($elem->cHersteller) . '"~"';
		$item .= $this->CSV_elem($elem->kHersteller) . '"~"';
		$item .= $this->CSV_elem($elem->cSeo) . '"~"';
		$image = $this->getPictureLink($elem);
		$item .= $this->CSV_elem($image) . '"~"';
		$item .= $this->CSV_elem($language['cISO']) . '"~"';
		$item .= $this->CSV_elem($elem->cSuchbegriffe) . '"~"';

		if ($elem->cTopArtikel == 'Y') {
			$item .= 'Y"~"';
		} else {
			$item .= 'N"~"';
		}

		$item .= $this->CSV_elem($elem->BME_Lieferzeit) . '"~"';

		$item .= $this->CSV_elem($elem->bestseller) . '"~"';


		$item .= $this->CSV_elem($elem->dErstellt) . '"~"';

		$elem->cBeschreibung = strip_tags($elem->cBeschreibung);
		if (strlen($elem->cBeschreibung) > 1000) {
			$elem->cBeschreibung = preg_replace("/^(.{0,1000}[^ ]*).*/ims", "\\1...", $elem->cBeschreibung);
		}
		$item .= $this->CSV_elem($elem->cBeschreibung) . '"~"';

		$elem->cKurzBeschreibung = strip_tags($elem->cKurzBeschreibung);
		if (strlen($elem->cKurzBeschreibung) > 1000) {
			$elem->cKurzBeschreibung = preg_replace("/^(.{0,300}[^ ]*).*/ims", "\\1...", $elem->cKurzBeschreibung);
		}
		$item .= $this->CSV_elem($elem->cKurzBeschreibung) . '"~"';
		$item .= $this->CSV_elem($this->getParentCatIDs($elem->catIDs, $catDataARR)) . '"~"';

		$catCSV = "";
		$catIDARR = explode(",", $elem->catIDs);
		$i = 0;
		foreach ($catIDARR as $catID) {
			if (key_exists($catID, $this->kategorieSichtbarkeit)){
				foreach ($this->kategorieSichtbarkeit[$catID] as $kKundengruppe){
					$this->artikelSichtbarkeit[$elem->kArtikel][$kKundengruppe] = true;
				}
			}
			if ($i > 0) {
				$catCSV .= '#';
			}
			$catCSV .= $this->catDataARR[$catID];
			$i++;
			//$item .= "BLUBB";
		}
		$item .= $this->CSV_elem($catCSV) . '"~"';
		$item .= $this->CSV_elem($elem->Merkmal) . '"~"';


		$item .= $this->CSV_elem($this->getPriceData($elem)) . '"~"';

		$varKombData = $elem->kVaterArtikel . '_' . $elem->nIstVater;

		$item .= $this->CSV_elem($varKombData) . '"~"';

		$item .= $this->CSV_elem($elem->fLagerbestand) . '"~"';

		$item .= $this->CSV_elem($elem->cISBN) . '"~"';

		$item .= $this->CSV_elem($elem->cASIN) . '"~"';
		
		//
		if (key_exists($elem->kArtikel, $this->artikelSichtbarkeit)){
			$ii = 0;
			foreach ($this->artikelSichtbarkeit[$elem->kArtikel] as $kKundengruppe=>$elem2){
				if($ii != 0){
					$item .= ',';
				}
				$item .= $kKundengruppe;
				$ii++;
			}
		}
		$item .= '"';

		/*
		  $item .= $this->CSV_elem($elem->childNames) . '"~"';
		  $item .= $this->CSV_elem($elem->childArtnr) . '"~"';
		  $item .= $this->CSV_elem($elem->childHAN) . '"';
		 */
		//echo "\n\n$item\n\n";
		$item .= PHP_EOL;
		return $item;
	}

	private function getParentCatIDs($catList) {
		$tmpListARR = explode(",", $catList);
		foreach ($tmpListARR as $elem) {
			//die($elem);
			if (key_exists($elem, $this->catDataARR)) {
				preg_match_all("/_([0-9]+)/", $this->catDataARR[$elem], $match);

				foreach ($match[1] as $newCatID) {

					$tmpListARR[] = $newCatID;
				}
				//die($catDataARR[$elem]);
			}
		}
		$tmpListARR = array_unique($tmpListARR);
		return implode(",", $tmpListARR);
	}

	private function getPriceData(&$elem) {
		$tmpPriceARR = array();
		$preisARR = explode("||", $elem->priceData);  //Kundengruppe_VKNetto,fMwSt;

		foreach ($preisARR as $elem2) {
			$tmpData = explode('_', $elem2);
			$kKundengruppe = $tmpData[0];
			$fVK = $tmpData[1];
			$fMwSt = $_SESSION['Steuersatz'][$tmpData[2]];


			$kundenGruppenRabatt = 0;
			if (key_exists($kKundengruppe, $this->tkundengruppeARR) && $this->tkundengruppeARR[$kKundengruppe]['fRabatt'] != 0) {
				$kundenGruppenRabatt = $this->tkundengruppeARR[$kKundengruppe]['fRabatt'];
			}

			$kategorieRabatt = 0;
			if (key_exists($elem->kArtikel, $this->kategorieRabattARR) && key_exists($kKundengruppe, $this->kategorieRabattARR[$elem->kArtikel])) {
				$kategorieRabatt = $this->kategorieRabattARR[$elem->kArtikel][$kKundengruppe];
			}
			//die($kategorieRabatt);
			$newPrice = $fVK;
			//Rabatte!
			if ($kategorieRabatt != 0 || $kundenGruppenRabatt != 0) {
				$rabatt = 0;
				if ($kategorieRabatt > $kundenGruppenRabatt) {
					$rabatt = $kategorieRabatt;
				} else {
					$rabatt = $kundenGruppenRabatt;
				}
				if ($rabatt > 0) {
					$tmpPriceARR[$kKundengruppe]['sp'] = 'true';
				}
				$newPrice = round($fVK - ($fVK / 100 * $rabatt), 2);
			}

			//Brutto/Netto???
			if (key_exists($kKundengruppe, $this->tkundengruppeARR) && $this->tkundengruppeARR[$elem->kKundengruppe]['nNettoPreise'] == '1') {
				$newPrice = round($newPrice, 2) * 100;
			} else {
				$newPrice = round($newPrice + ($newPrice / 100 * $fMwSt), 2) * 100;
			}
			$tmpPriceARR[$kKundengruppe]['price'] = $newPrice;
		}

		$sonderpreisARR = explode("||", $elem->sonderpreisData);  //Kundengruppe_VKNetto,fMwSt;
		foreach ($sonderpreisARR as $elem2) {
			$tmpData = explode('_', $elem2);
			$kKundengruppe = $tmpData[0];
			$fVK = $tmpData[1];
			$fMwSt = $_SESSION['Steuersatz'][$tmpData[2]];

			$newPrice = $fVK;
			//Brutto / Netto???
			if (key_exists($kKundengruppe, $this->tkundengruppeARR) && $this->tkundengruppeARR[$kKundengruppe]['nNettoPreise'] == '1') {
				$newPrice = round($newPrice, 2) * 100;
			} else {
				$newPrice = round($newPrice + ($newPrice / 100 * $fMwSt), 2) * 100;
			}
			if ($newPrice < $tmpPriceARR[$kKundengruppe]['price']) {
				$tmpPriceARR[$kKundengruppe]['price'] = $newPrice;
				$tmpPriceARR[$kKundengruppe]['sp'] = 'true';
			}
		}

		$ii = 0;
		foreach ($tmpPriceARR as $kKundengruppe => $price) {
			if ($ii > 0) {
				$data .= ',';
			}
			$data .= $kKundengruppe . '_' . $price['price'];
			if ($price['sp'] == 'true') {
				$data .= '_SP';
			}
			$ii++;
		}
		return $data;
	}

	private function getParent($kKategorie, $content, $i, $tmpCatARR) {
		$i++;

		if ($i > 10) {
			return $content;
		} else {
			if (key_exists($kKategorie, $tmpCatARR)) {
				$content = $tmpCatARR[$kKategorie]["nSort"] . "_" . $tmpCatARR[$kKategorie]["cName"] . "_" . $kKategorie . "|" . $content;
				if ($tmpCatARR[$kKategorie]["kOberKategorie"] > 0) {
					$content = $this->getParent($tmpCatARR[$kKategorie]["kOberKategorie"], $content, $i, $tmpCatARR);
				}
			}
		}
		return $content;
	}

	private function getCatData($languageARR) {
		$this->catDataARR = array();
		$sql = "SELECT
			A.kKategorie
			, COALESCE(A.cName, B.cName) AS cName
			, nSort
			, kOberKategorie
			FROM tkategorie AS A 
			LEFT JOIN tkategoriesprache AS B ON A.kKategorie = B.kKategorie AND B.kSprache = " . $languageARR['kSprache'];
		//die($sql);
		$result = Shop::DB()->executeQuery($sql, 10);
		//Make Tree to Array!
		$tmpCatARR = array();
		while ($elem = $result->fetchObject()) {
			$tmpCatARR[$elem->kKategorie]["cName"] = $elem->cName;
			$tmpCatARR[$elem->kKategorie]["nSort"] = $elem->nSort;
			$tmpCatARR[$elem->kKategorie]["kOberKategorie"] = $elem->kOberKategorie;
		}

		$this->catDataARR = array();
		foreach ($tmpCatARR as $catID => $tmpCat) {
			$content = $tmpCat["nSort"] . "_" . $tmpCat["cName"] . "_" . $catID;

			if ($tmpCat["kOberKategorie"] > 0) {

				$content = $this->getParent($tmpCat["kOberKategorie"], $content, 0, $tmpCatARR);
			}

			$this->catDataARR[$catID] = $content;
		}

		$tmpCatARR = array();
		unset($tmpCatARR);
	}

}
