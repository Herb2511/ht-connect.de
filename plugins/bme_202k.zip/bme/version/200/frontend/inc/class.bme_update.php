<?php

class bme_update {
	public function __construct(){
	}
	
	
	public function setUpdateByKhersteller($khersteller){

		$sql = "SELECT
				kArtikel
				FROM tartikel AS A
				WHERE A.kHersteller = '" . $GLOBALS['DB']->escape($khersteller) . "'";
		
		$result = Shop::DB()->executeQuery($sql, 9);
		
		$kArtikelARR = array();
		foreach ($result as $elem) {
			$this->setUpdateByKartikel($elem['kArtikel']);
		}
		
	}
	
	public function setUpdateByKkategorie($kKategorie){

		//Check for kOberkategorie and Sub?
		$sql = "SELECT
			kArtikel
			FROM tkategorie  AS A
			LEFT JOIN tkategorieartikel AS B ON A.kKategorie = B.kKategorie
			WHERE
			(A.kKategorie = '" . $kKategorie . "' OR A.kOberKategorie = '" . $kKategorie . "')
			AND B.kArtikel != ''
			";
		$result = Shop::DB()->executeQuery($sql, 9);
		
		$kArtikelARR = array();
		foreach ($result as $elem) {
			$this->setUpdateByKartikel($elem['kArtikel']);
		}
		
	}
	
	public function setDeleteByKkategorie($kKategorie){
	}
	public function setDeleteByKartikel($kArtikel){
		
		$sql = "INSERT INTO xplugin_bme_update_article
				SET kArtikel = " . $kArtikel . ",
				type = 'delete',
				ts= '" . date("Y-m-d H:i:s") . "'
				ON DUPLICATE KEY UPDATE
				ts = '" . date("Y-m-d H:i:s") . "'";
		
		Shop::DB()->executeQuery($sql, 3);
		
	}
	
	public function setUpdateByKartikel($kArtikel){
		if (!is_numeric($kArtikel)){
			return;
		}
		

		$sql = "INSERT INTO xplugin_bme_update_article 
				SET kArtikel = " . $kArtikel . ", 
				type = 'update', 
				ts= '" . date("Y-m-d H:i:s") . "'
				ON DUPLICATE KEY UPDATE 
				ts = '" . date("Y-m-d H:i:s") . "'";
						
		Shop::DB()->executeQuery($sql, 3);
	}
	
}