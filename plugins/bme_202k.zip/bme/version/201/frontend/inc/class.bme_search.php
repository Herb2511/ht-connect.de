<?php

class bme_search {
	
	private $pluginVersion = "201";
	private $pluginRevision = "s";
	
	
	private $bStatus = false;
	private $JTLSettings;
	private $JTLHash;
	private $bJTLStatusBME = false;
	private $kKundengruppe = 1;
	
	private $startPos = 0;
	private $kKunde = 0;
	
	private $query = '';
	private $resultARR;
	private $searchUrl = '/navi.php';
	private $searchType = 'ajax';
	
	private $postHersteller = '';
	private $postSort = '';
	private $postMerkmale = '';
	private $postMin = '';
	private $postMax= '';
	private $postSpecial = '';
	private $postCategories = '';
	
	protected static $_instance = null;

	public static function getInstance() {
		
		if (null === self::$_instance) {
			self::$_instance = new self;
		}
		return self::$_instance;
	}

	protected function __construct() {
		$this->getShopDataHash();
		$this->getURLParamARR();
		
		$this->resultARR = new stdClass();
		$this->resultARR->manufacturer = new stdClass();
		$this->resultARR->manufacturerType = '';
		$this->resultARR->hits = '';
		$this->resultARR->items = array();
	}


		
	
	public function getVersion() {
		return $this->pluginVersion  . $this->pluginRevision;
	}
	
	
	public function getStatus() {
		//return false;
		$postdata = http_build_query(
				array(
					'status' => 'true'
				)
		);

		$opts = array('http' =>
			array(
				'method' => 'POST',
				'content' => $postdata,
				'timeout' => 1,
				//'header' => "Origin: " . URL_SHOP . "\r\n" . 
				'header' => "Origin: " . $_SERVER['SERVER_NAME'] . "\r\n" . 
				"Content-Type: application/x-www-form-urlencoded\r\n".
                    "Content-Length: ".strlen($postdata)."\r\n"
			)
		);

		$context = stream_context_create($opts);

		$result = file_get_contents('https://suche.bm-suche.de/bm-suche.de', false, $context);
		if ($result == "-status-"){
			$this->bStatus = true;
		}
		else {
			$this->bStatus = false;
			//die($result."ERROR");
		}
		return $this->bStatus;
	}
	
	
	public function setQuery($query) {
		$this->query = $query;
	}
	
	public function getQuery() {
		return $this->query;
	}
	
	private function getHits() {
		return $this->resultARR->hits;
	}


	public function setStartPos($pos){
		if (is_numeric($pos)){
			$this->startPos = $pos - 1;
		}
	}

	
	
	public function queryBME() {
		$postdata = http_build_query(
				array(
					'q' => $this->query
					, 'manufacturerID' => $this->postHersteller
					, 'categoryID'  => $this->postCategories
					, 'minPrice' => $this->postMin
					, 'maxPrice' => $this->postMax
					, 'sort' => $this->postSort
					, 'merkmale' => $this->postMerkmale
					, 'special' => $this->postSpecial
					, 'jtlSetting' => $this->JTLSettings
					, 'hash' => $this->JTLHash
					, 'startPagination' => $this->startPos
				)
		);
		//print_r($postdata);die();
		$opts = array('http' =>
			array(
				'method' => 'POST',
				'content' => $postdata,
				'timeout' => 1,
				//'header' => "Origin: " . URL_SHOP . "\r\n". 
				'header' => "Origin: " .  $_SERVER['SERVER_NAME'] . "\r\n". 
				"Content-Type: application/x-www-form-urlencoded\r\n".
                    "Content-Length: ".strlen($postdata)."\r\n"
			)
		);

		$context = stream_context_create($opts);

		$result = file_get_contents('https://suche.bm-suche.de/bm-suche.de', false, $context);
		$result = json_decode($result);
		$result = $this->utf8Decode($result);

		 $this->resultARR = $result;
		$ii = 0;
		foreach ($this->resultARR->items as $key=>$elem){
			$this->resultARR->items[$key]->iteration = $ii;
			$ii++;
			$this->resultARR->items[$key]->position = $ii;
		}
		
		//echo "<pre>";print_r($this->resultARR);die("No Result???");
	}
	
	public function utf8Decode($data){
		if (is_array($data)){
			foreach ($data as $key=>$elem){
				$data[$key] = $this->utf8Decode($elem);
			}
			return $data;
		}
		elseif (is_object($data)) {
			foreach ($data as $key=>$elem){
				$data->$key = $this->utf8Decode($elem);
			}
			return $data;
		}
		else if (is_string($data)){
			//die("111");
			return utf8_decode($data);
		}

		return($data);
	}
	
	public function getResultARR(){
		return $this->resultARR;
	}
	
	private function getResultArticleARR(){
		//echo "<pre>";print_r($this->resultARR->items);die();
		return $this->resultARR->items;
	}
	
	private function getManufacturerType(){
		return $this->resultARR->manufacturerType;
	}

	public function getoItem_arr() {
		
		$this->queryBME();
		$itemARR = array();
		if (property_exists($this->resultARR, 'items') && is_array($this->resultARR->items)){
			foreach ($this->resultARR->items as $elem) {
				$article = new stdClass();
				$article->nId = $elem->id;

				$itemARR[] = $article;
			}
		}
		
		return $itemARR;
	}

	
	public function setJTLStatusBME($status){
		
	}
	
	public function setKKundengruppe($kKundengruppe){
		$this->kKundengruppe = $kKundengruppe;
	}
	public function setKKunde($kKunde){
		$this->kKunde = $kKunde;
	}
	
	
	
	private function getURLParamARR(){
		foreach ($_GET as $key => $value){
			if ($key == "qs" || $key == "suche" || $key == "seite" || preg_match("/^bme/i", $key)){
				$value = html_entity_decode($value);
				
				//die($value);
				
				$this->URLParams[$key] = $value;
				
				if ($key == "bme_mf"){
					$this->setPostManufacturer($value);
				}
				else if ($key == "bme_ct"){
					$this->setPostCategories($value);
				}
				else if ($key == "bme_min"){
					$this->setPostMin($value);
				}
				else if ($key == "bme_max"){
					$this->setPostMax($value);
				}
				else if ($key == "bme_so"){
					$this->setPostSort($value);
				}
				else if ($key == "bme_me"){
					$this->setPostMerkmale($value);
				}
				else if ($key == "bme_sp"){
					$this->setPostSpecial($value);
				}
			}
			
		}
	}

	private function setPostManufacturer($value){
		$value = preg_replace("/[^,0-9]/", "", $value);
		$this->postHersteller = $value;
	}
	private function setPostCategories($value){
		$value = preg_replace("/[^,0-9]/", "", $value);
		$this->postCategories = $value;
	}
	private function setPostMin($value){
		$value = str_replace(",",".",$value);
		$value = preg_replace("/[^.0-9]/", "", $value);
		$this->postMin = $value;
	}
	private function setPostMax($value){
		$value = str_replace(",",".",$value);
		$value = preg_replace("/[^.0-9]/", "", $value);
		$this->postMax = $value;
	}
	
	private function setPostSort($sort){
		switch($sort){
			case 'rel':
			case '09':
			case '90':
			case 'az':
			case 'za':
			case 'date':
				$this->postSort = $sort;
				break;
			
			default:
				$this->postSort = 'rel';
				break;
		}
	}
	
	private function setPostMerkmale($value){
		$value = preg_replace("/[^,a-z_0-9]/i", "", $value);
		$this->postMerkmale = $value;
	}
	
	private function setPostSpecial($value){
		$value = preg_replace("/[^,a-z]/", "", $value);
		$this->postSpecial = $value;
	}
	
	
	private function getHerstellerFilter() {
		$returnARR = array();
		//print_r($this->resultARR->manufacturer);die();
		if(property_exists($this->resultARR, 'manufacturer') && is_array($this->resultARR->manufacturer)){
			foreach ($this->resultARR->manufacturer as $manufacturer){
				$data = new stdClass();
				$data->nAnzahl = $manufacturer->count;
				$data->cName = $manufacturer->name;
				$data->kHersteller = $manufacturer->id;
				$selected = 'N';
				if(property_exists($manufacturer, 'selected')){
					$selected = 'Y';
				}
				$data->selected = $selected;

				$returnARR[] = $data;
			}
		}
		//echo "<pre>";print_r($returnARR);die();
		return $returnARR;
		//$smarty->tpl_vars['Suchergebnisse']->value->Herstellerauswahl[] = $data;
	}
	
	private function getShowCart(){
		//echo "<pre>";print_r($this->resultARR->settings->showCart);die();
		//die($this->resultARR->settings->showCart);
		if (!property_exists($this->resultARR, 'settings')){
			return 'N';
		}
		switch ($this->resultARR->settings->showCart){
			case 'Y':
				return 'Y';
				break;
			default:
			case 'N':
				return 'N';
				break;
		}
	}
	private function getCategoryFilter() {
		$returnARR = array();
		//echo "<pre>";print_r($this->resultARR);die();
		if( property_exists($this->resultARR, 'catARR') && is_array($this->resultARR->catARR)){
			foreach ($this->resultARR->catARR as $category){
				$data = new stdClass();
				$data->title = $category->name;
				$data->id = $category->id;
				$data->level = $category->lvl;
				$selected = 'N';
				if(property_exists($category, 'selected')){
					$selected = 'Y';
				}
				$data->selected = $selected;

				$returnARR[] = $data;
			}
		}
		//echo "<pre>";print_r($returnARR);die();
		return $returnARR;
		//$smarty->tpl_vars['Suchergebnisse']->value->Herstellerauswahl[] = $data;
	}
	
	public function getCSS(&$oPlugin){
		$filename = PFAD_ROOT . PFAD_PLUGIN . $oPlugin->cVerzeichnis . "/" . PFAD_PLUGIN_VERSION . $oPlugin->nVersion . "/frontend/template/" . $oPlugin->oPluginEinstellungAssoc_arr['bme_template_name'] . "/bme_tpl.css";
		
		$filenameExtension = PFAD_ROOT . PFAD_PLUGIN . $oPlugin->cVerzeichnis . "/" . PFAD_PLUGIN_VERSION . $oPlugin->nVersion . "/frontend/template/" . $oPlugin->oPluginEinstellungAssoc_arr['bme_template_name'] . "/bme_tpl_extend.css";
		
		if (file_exists($filename)){
			$retData = '<style type="text/css">';
			$retData .= file_get_contents($filename);
			if (file_exists($filenameExtension)){
				$retData .= file_get_contents($filenameExtension);
			}
			$retData .= "</style>";
		}
		return $retData;
	}
	public function getPageTemplate(&$smarty, &$oPlugin){
		//TODO
		//$this->oPlugin->cVerzeichnis .
		//echo "<pre>";print_r(get_defined_constants());
		//echo "<pre>";print_r($oPlugin);
		$dir = PFAD_ROOT . PFAD_PLUGIN . $oPlugin->cVerzeichnis . "/" . PFAD_PLUGIN_VERSION . $oPlugin->nVersion . "/frontend/template/" . $oPlugin->oPluginEinstellungAssoc_arr['bme_template_name'] . "/";
		//die($dir);
		$file = $dir . "bme";
		
		$smarty->assign ( 'bme_articleTemplate', $dir . "bme_articleTemplate.tpl");
		
		$smarty->assign ( 'bme_search_active', $oPlugin->oPluginEinstellungAssoc_arr['bme_search_active']);
		
		
		
		
		$smarty->assign ( 'bme_jtl', $this->JTLSettings );
		$smarty->assign ( 'bme_hash', $this->JTLHash );
		
		
		if ( file_exists($file . "_custom.tpl") ){
			$HTML = $smarty->fetch ( $file . "_custom.tpl");
		}
		else {
			$HTML = $smarty->fetch ( $file . ".tpl" );
		}
		return $HTML;
	}

	private function getShopDataHash() {
		$jtl_data = array ();

		if(key_exists('Kunde', $_SESSION)){
			$jtl_data [] = $_SESSION ['Kunde']->kKunde;
		}
		else {
			$jtl_data [] = '';
		}
		if(key_exists('Kundengruppe', $_SESSION)){
			$jtl_data [] = $_SESSION ['Kundengruppe']->kKundengruppe;
		}
		else {
			$jtl_data [] = '';
		}
		$jtl_data [] = session_id ();
		$jtl_data [] = time ();
		if (key_exists('cISOSprache', $_SESSION)){
			$jtl_data [] = $_SESSION ['cISOSprache'];
		}
		else {
			$jtl_data [] = '';
		}
		
		$this->JTLSettings = implode ( "_", $jtl_data );
		
		$this->JTLHash = md5 ( "hash" . $this->JTLSettings . "bme" );
		
	}
	public function getMerkmalFilter() {
		$returnARR = array();
		//echo "<pre>";print_r($this->resultARR);die();
		if(property_exists($this->resultARR, 'merkmale')){
			foreach ($this->resultARR->merkmale as $merkmal){
				$data = new stdClass();
				$data->cName = ($merkmal->title);
				$data->cTyp = 'SELECTBOX';
				switch ($merkmal->type){
					case 'selectmulti':
					default:
					$data->cTyp = 'SELECTBOX';
				}

				$data->kMerkmal = $merkmal->id;
				foreach ($merkmal->values as $value){
	//				print_r($value);die();
					$dataValue = new stdClass();
					$dataValue->nAktiv = 0;
					$tmpARR = explode("_", $value->id);
					$dataValue->kMerkmalWert = $tmpARR[2];
					$dataValue->cWert = $value->title;
					$dataValue->nAnzahl = $value->count;
					$selected = 'N';
					if(property_exists($dataValue, 'selected')){
						$selected = 'Y';
					}
					$dataValue->selected = $selected;
					$dataValue->cBildpfadKlein =  "gfx/keinBild_kl.gif";
					$dataValue->cBildpfadGross = "gfx/keinBild_kl.gif";
					$data->oMerkmalWerte_arr[] = $dataValue;
				}
			/*
			 * cSeo: "ACME",
kHersteller: "62",
cName: "ACME",
nSortNr: "0",
nAnzahl: "1",
cURL: "http://jtl.local/navi.php?suche=akku&amp;hf=62"
			 */
				$returnARR[] = $data;
			}
		}
		
		//echo "<pre>";print_r($returnARR);die();
		return $returnARR;
		//$smarty->tpl_vars['Suchergebnisse']->value->Herstellerauswahl[] = $data;
	}
	
	private function getSpecialFilter() {
		$returnARR = array();
		//echo "<pre>";print_r($this->resultARR);die();
		if(property_exists($this->resultARR, 'special')){
			$bUseTag = false;
			foreach ($this->resultARR->special as $type => $data){
				switch($type){

					case 'sonderpreis':
					case 'topartikel':
					case 'bestseller':
					case 'stock':
						//TODO translate from variables?
						$bUseTag = true;
						break;

					default:
					case 'stockshort':
					case 'stockmedium':
						$bUseTag = false; 
						break;
				}
				if($bUseTag){
					$retData = new stdClass();
					$retData->cName = utf8_decode($type);
					$retData->nAnzahl = $data->count;

					$returnARR[$type] = $retData;
				}
			}
		}
		//echo "<pre>";print_r($returnARR);die();
		return $returnARR;
		//$smarty->tpl_vars['Suchergebnisse']->value->Herstellerauswahl[] = $data;
	}
	
	private function getSelectedFilter() {
		$returnARR = array();
		//echo "<pre>";print_r($this->resultARR->activeFilters);//die();
		if(property_exists($this->resultARR, 'activeFilters')){
			foreach ($this->resultARR->activeFilters as $elem){
				$returnARR[$elem->type][$elem->id] = $elem->name;
			}
		}
		//echo "<pre>";print_r($returnARR);die();
		return $returnARR;
		//$smarty->tpl_vars['Suchergebnisse']->value->Herstellerauswahl[] = $data;
	}
	
	
	
	public function getSmartyEmptyArticle() {
		$emptyArticle = array();
		$emptyArticle[0] = new stdClass();
		$emptyArticle[0]->id = 'bme_article_template';
		$emptyArticle[0]->deeplink = '';
		$emptyArticle[0]->description = '';
		$emptyArticle[0]->artnr = '';
		$emptyArticle[0]->han = '';
		$emptyArticle[0]->ean = '';
		$emptyArticle[0]->isbn = '';
		$emptyArticle[0]->asin = '';
		$emptyArticle[0]->title = '';
		$emptyArticle[0]->manufacturer = new stdClass();
		$emptyArticle[0]->manufacturer->id = '';
		$emptyArticle[0]->manufacturer->name = '';
		$emptyArticle[0]->vk = '';
		$emptyArticle[0]->vpe = array();
		$emptyArticle[0]->vpeUnit = '';
		$emptyArticle[0]->vpeValue = '';
		$emptyArticle[0]->image = '';
		$emptyArticle[0]->iteration = '';
		$emptyArticle[0]->position = '';
		$emptyArticle[0]->showFilter = new stdClass();
		$emptyArticle[0]->showFilter->bestseller = 'N';
		$emptyArticle[0]->showFilter->topartikel = 'N';
		$emptyArticle[0]->showFilter->sonderpreis = 'N';
		$emptyArticle[0]->showFilter->stock = 'N';
		return $emptyArticle;
	}
	
	public function getSmartyBME(&$oPlugin) {
		
		
		$return = new stdClass();
		$return->currentSearch = utf8_decode($this->getQuery());
		$return->countHits = $this->getHits();
		$return->filterHersteller = $this->getHerstellerFilter();
		$return->resultArticle = $this->getResultArticleARR();
		
		$return->manufacturerType = $this->getManufacturerType();
		$return->resultCategories = $this->getCategoryFilter();
		$return->showCart = $this->getShowCart();
		$return->filterSpecial = $this->getSpecialFilter();
		$return->filterMerkmale = $this->getMerkmalFilter();
		$return->countMoreResults = $this->countMoreResults();
				
		$return->selectedFilter = $this->getSelectedFilter();
		
		$return->currentSort = $this->postSort;
		$return->currencyHTML = $_SESSION['Waehrung']->cNameHTML;
		$return->currencyFaktor = $_SESSION['Waehrung']->fFaktor;
		
		
		
		//Workarround, for JTL Bug: "missing oPluginEinstellungAssoc_arr"
		$bme_sprachARR = array();
		if (isset($_SESSION['cISOSprache']) && strlen($_SESSION['cISOSprache']) > 0) {
            $cISOSprache = $_SESSION['cISOSprache'];
			foreach ($oPlugin->oPluginSprachvariable_arr as $elem){
				$bme_sprachARR[$elem->cName] = $elem->oPluginSprachvariableSprache_arr[strtoupper($cISOSprache)];
			}
			$return->language = $bme_sprachARR;
        }
		else {
			$return->language = $oPlugin->oPluginSprachvariableAssoc_arr;
		}
		
		

		if($oPlugin->oPluginEinstellungAssoc_arr['bme_sitelinksSearchbox'] == 'Y'){
			$return->sitelinksSearchbox = URL_SHOP;
		}
		//echo "<pre>";print_r($return);die();
		return $return;
	}
	
	
	private function countMoreResults() {
		$hits = $this->resultARR->hits;
		//echo "<pre>";
		//print_r($this->resultARR->items);die();
		$keys = array_keys($this->resultARR->items);
		$currentpos = end($keys) + 1;
		$remaining = (int) $hits - (int) $currentpos;
		//echo "<hr>...".$hits."--".$currentpos."...".$remaining;
		
		//die("???".$remaining);
		return $remaining;
	}
	
	
	
	public function getCountHits(){
		return $this->resultARR->hits;
	}
	
	public function getSearchType(){
		return $this->searchType;
	}
	
	public function setSearchType($type){
		switch ($type){
			case 'ajax':
			case 'page':
				$this->searchType = $type;
				break;
		}
	}
}


class JtlSearch {

		public static function getFilter($cParamAssoc_arr) {
			$cFilter_arr = [];
//			for ($i = 0; $i < 20; $i++) {
//				if (isset($cParamAssoc_arr["fq{$i}"])) {
//					$cFilter_arr[] = $cParamAssoc_arr["fq{$i}"];
//				}
//			}

			return $cFilter_arr;
		}

		public static function buildFilterShopURL($cFilter_arr)
		{

			return '';
		}

	}