<?php
require_once PFAD_ROOT . PFAD_ADMIN . PFAD_INCLUDES . PFAD_WIDGETS . 'class.WidgetBase.php';

class WidgetBMSuche_bme extends WidgetBase {
	private $indexDataARR;

	/**
	 *
	 */
	public function init() {
		$this->getIndexData();
		
		$this->oSmarty->assign('bmeWidget_NewestVersion', $this->indexDataARR->currentVersion);
		$this->oSmarty->assign('bmeWidget_CurrentVersion', $this->getCurrentVersion());
		$this->oSmarty->assign('bmeWidget_AdminURL', "https://admin.bm-suche.de");
		$this->oSmarty->assign('bmeWidget_status', $this->getSuchStatus());
		$this->oSmarty->assign('bmeWidget_countIndexItems', $this->indexDataARR->countIndex);
	}
	
	private function getIndexData() {
		
		$postdata = http_build_query(
				array(
					'widget' => 'true'
				)
		);
		
		
		$opts = array('http' =>
			array(
				'method' => 'POST',
				'content' => $postdata,
				'timeout' => 1,
				'header' => "Origin: " .  $_SERVER['SERVER_NAME'] . "\r\n". 
				"Content-Type: application/x-www-form-urlencoded\r\n".
                    "Content-Length: ".strlen($postdata)."\r\n"
			)
		);

		$context = stream_context_create($opts);

		$result = file_get_contents('https://suche.bm-suche.de/bm-suche.de', false, $context);
		$result = json_decode($result);
		$this->indexDataARR = $result;
		
		//TODO get aktive Articles
		//TODO get currentVersion
	}
	
	private function getSuchStatus(){
		//print_r($oPlugin);die();
	}
	
	private function getCurrentVersion(){
		require_once dirname(__FILE__) . '/../../frontend/inc/class.bme_search.php';

		$version = bme_search::getInstance()->getVersion();
		return $version;
	}

	/**
	 * @return string
	 */
	public function getContent() {
		return $this->oSmarty->fetch(dirname(__FILE__) . '/widgetBMSuche.tpl');
	}

}
