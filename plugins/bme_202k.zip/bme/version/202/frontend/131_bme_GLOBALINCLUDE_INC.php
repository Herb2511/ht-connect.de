<?php
try {
	if (isset ( $_GET ["bme"] )) {
		if (isset ( $_POST ['pw'] )) {
			ob_start("ob_gzhandler");
			if (! class_exists ( 'bme_index' )) {
				require_once (dirname ( __FILE__ ) . '/inc/class.bme_index.php');
			}
				
			$index = new bme_index ( $oPlugin );
			if (isset($_POST['lastKArtikel'])){
				$index->setLimitLastKArtikel($_POST['lastKArtikel']);
			}
			if (isset($_POST['limit'])){
				$index->setLimit($_POST['limit']);
			}
			if ($index->getCSV ()) {
				die ();
			}
			
		} else {
//			throw new Exception ( 'wrong login/sync password for import' );
		}
	}
} catch ( Exception $oEx ) {
	error_log ( "\nError: \n" . print_r ( $oEx, true ) . " \n", 3, PFAD_ROOT . 'jtllogs/bme_error.txt' );
}
?>