<?php
try {
	if (key_exists('Artikel', $args_arr) && count ($args_arr['Artikel']) > 1){

		if(!class_exists('bme_update')){
			require_once (dirname(__FILE__) . '/inc/class.bme_update.php');
		}

		$bme_update = new bme_update();
		
		foreach ($args_arr['Artikel'] as $elem){
			
			$bme_update -> setUpdateByKartikel( $elem->kArtikel );
			
		}
	}
} catch (Exception $oEx) {
	error_log("\nError: \n" . print_r($oEx, true) . " \n", 3, PFAD_ROOT . 'jtllogs/bme_error.txt');
}