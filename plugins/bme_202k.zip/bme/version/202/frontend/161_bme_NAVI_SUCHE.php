<?php
GLOBAL $smarty;

if ($args_arr['bExtendedJTLSearch']){
	require_once dirname(__FILE__) . '/inc/class.bme_search.php';
	//print_r($args_arr);die();
	
	bme_search::getInstance()->setSearchType('page');
	
	
	bme_search::getInstance()->setQuery($args_arr['cValue']);
	
	
	$result = new stdClass();
	$result->oSearch = new stdClass();
	$result->oSearch->oItem_arr = bme_search::getInstance()->getoItem_arr();;
	
	$args_arr['oExtendedJTLSearchResponse'] = $result;
	$args_arr['oExtendedJTLSearchResponse']->oSearch->nItemFound = bme_search::getInstance()->getCountHits();
	$args_arr['oExtendedJTLSearchResponse']->oSearch->GesamtanzahlArtikel = bme_search::getInstance()->getCountHits();

	


	
}
