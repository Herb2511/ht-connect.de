<?php
try {
	if (isset($args_arr['oHersteller']->kHersteller) && is_numeric($args_arr['oHersteller']->kHersteller) && $args_arr['oHersteller']->kHersteller > 0) {
	
		if(!class_exists('bme_update')){
			require_once (dirname(__FILE__) . '/inc/class.bme_update.php');
		}
		
		$bme_update = new bme_update();
		$bme_update -> setUpdateByKhersteller($args_arr['oHersteller']->kHersteller);
		
	}
} catch (Exception $oEx) {
	error_log("\nError: \n" . print_r($oEx, true) . " \n", 3, PFAD_ROOT . 'jtllogs/bme_error.txt');
}
?>