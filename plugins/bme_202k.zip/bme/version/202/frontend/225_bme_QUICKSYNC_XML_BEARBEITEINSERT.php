<?php
try {
	if (isset($args_arr['oArtikel']->kArtikel) && is_numeric($args_arr['oArtikel']->kArtikel) && $args_arr['oArtikel']->kArtikel > 0) {

		if(!class_exists('bme_update')){
			require_once (dirname(__FILE__) . '/inc/class.bme_update.php');
		}

		$bme_update = new bme_update();
		$bme_update -> setUpdateByKartikel( $args_arr['oArtikel']->kArtikel);
		
	}
} catch (Exception $oEx) {
	error_log("\nError: \n" . print_r($oEx, true) . " \n", 3, PFAD_ROOT . 'jtllogs/bme_error.txt');
}