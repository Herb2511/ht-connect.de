<?php
class bme_update {
	public function __construct(){
	}
	
	
	public function setUpdateByKhersteller($khersteller){
		$sql = "SELECT
				kArtikel
				FROM tartikel AS A
				WHERE A.kHersteller = '" . $GLOBALS['DB']->escape($khersteller) . "'";
		
		$result = Shop::DB()->executeQuery($sql, 9);
		
		$kArtikelARR = array();
		foreach ($result as $elem) {
			$kArtikelARR[] = $elem['kArtikel'];
		}
		$this->setUpdateByKartikelARR($kArtikelARR);
		
	}
	
	public function setUpdateByKkategorie($kKategorie){

		//Check for kOberkategorie and Sub?
		$sql = "SELECT
			kArtikel
			FROM tkategorie  AS A
			LEFT JOIN tkategorieartikel AS B ON A.kKategorie = B.kKategorie
			WHERE
			(A.kKategorie = '" . $kKategorie . "' OR A.kOberKategorie = '" . $kKategorie . "')
			AND B.kArtikel != ''
			";
		$result = Shop::DB()->executeQuery($sql, 9);
		
		$kArtikelARR = array();
		foreach ($result as $elem) {
			$kArtikelARR[] = $elem['kArtikel'];
		}
		$this->setUpdateByKartikelARR($kArtikelARR);
	}
	
	public function setDeleteByKkategorie($kKategorie){
	}
	
	public function setDeleteByKartikel($kArtikel){
		
		$sql = "INSERT IGNORE INTO xplugin_bme_delete_kArticle
				SET kArtikel = " . $kArtikel ;
		
		Shop::DB()->executeQuery($sql, 3);
		
	}
	
	public function setUpdateByKartikel($kArtikel){
		if (!is_numeric($kArtikel)){
			return;
		}
		$sql = "INSERT IGNORE INTO xplugin_bme_update_kArticle 
				SET kArtikel = " . $kArtikel ;
						
		Shop::DB()->executeQuery($sql, 3);
	}
	
	public function setUpdateByKartikelARR(&$kArtikelARR){
		if (is_array($kArtikelARR) && count($kArtikelARR) > 0){
			$sql = 'INSERT IGNORE INTO xplugin_bme_update_kArticle 
				(kArtikel) values (' . implode(',', $kArtikelARR) . ')';
			Shop::DB()->executeQuery($sql, 3);
		}
		return;
	}
	
}