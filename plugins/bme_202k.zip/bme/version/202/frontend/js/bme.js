var bme = {};
bme.AJAXURL = 'https://suche.bm-suche.de/bm-suche.de';
bme.initialised = false;	
bme.trackAnalytics = false;
bme.startURL = '';

bme.xhr;

bme.suggestData;



bme.manufacturer = "";
bme.manufacturer_filter_id = "";
bme.category_filter_id = "-";
bme.current_filter_price = "";

bme.sort;

bme.queryHash = "";

bme.searchTimeout = 250;
bme.ajaxTimer = 0;


bme.searchInputData = "";

bme.filterIsSet = false;
bme.queryBykHerstellerID = 0;



bme.setAJAXurl = function(){
	if (/MSIE 10/i.test(navigator.userAgent)
		||  /MSIE 9/i.test(navigator.userAgent) || /rv:11.0/i.test(navigator.userAgent)
		|| /Edge\/\d./i.test(navigator.userAgent)
		){
			
			bme.AJAXURL = $("#bme_results").attr("data-url");
			bme.AJAXURL += "/index.php?bme=true";
        }
}

$( document ).ready(function() {
	bme.setAJAXurl();

	$('body').on('focus', '.bme_input', function (e) {
		if ($(this).val() != ''){
			bme.showSearchWindow($(this).val())
		}
	});

	$('.bme_input').closest('form').on('submit', function (e) {
		$('.bme_input').blur();
		e.preventDefault();
	});
});


bme.eventTracking = function(category, action, name){
	if (!bme.trackAnalytics){
		if(window.ga && ga.create) {
			bme.trackAnalytics = 'ga';
		}
		else if (typeof("_paq") === "object") {
			bme.trackAnalytics = 'piwik';
		}
		else {
			bme.trackAnalytics = 'none';
		}
	}

	if (bme.trackAnalytics == 'ga'){
		//ga('send', 'event', [eventCategory], [eventAction], [eventLabel], [eventValue])
		ga('send', 'event', category, action, name);
	}
	else if (bme.trackAnalytics == 'piwik'){
		//_paq.push(['trackEvent', 'Documentary', 'Rating', 'Thrive', 9.5]);
		_paq.push(['trackEvent', category, action, name]);
	} 
}

bme.eventTrackingFilter = function(action, value){
	bme.eventTracking('bm-suche filter', action, value);
}

bme.pageTrackingSuche = function(newUrl){
	if (bme.trackAnalytics == 'ga'){
		ga('send', 'pageview', '/' + newUrl);
	}
}

bme.eventTrackingSuche = function(action, value){
	bme.eventTracking('bm-suche suche', action, value);
}

bme.eventTrackingAktion = function(action, value){
	bme.eventTracking('bm-suche action', action, value);
}



bme.block_filters = function(status){
	if (status){
		if (!$("#bme_filter_blocker").length){
			$(".bme_filter_header").before('<div id="bme_filter_blocker"></div>');
		}
		$("#bme_filter_blocker").show();
	}
	else {
		$("#bme_filter_blocker").hide();
	}
}


bme.show_error = function(){
	$('#bme_error').show();
	$('#bme_article_list').hide();
}

bme.show_waiting = function(){
	$('#bme_waiting').show();
}

bme.hide_waiting = function(){
	$('#bme_waiting').show();
}



bme.init = function(){
	bme.initialised = true;
	
	bme.lastSearch = $(".bme_input").val();

	bme.select2();
	
	$(document).on('click', '#bme_container a', function(event) {
		if ($(this).attr("href") && $(this).attr("href") != ''){
			event.preventDefault();
			bme.eventTrackingAktion('click', newlink);
			setTimeout(function(){
				window.location.href = newlink;
				}, 100);
			
		}
	});

	
	$('body').on('change', '#bme_merkmalContainer select', function(e){
		e.preventDefault();
		ii = 0;
		bme_tmpMerkmale = '';
		$('#bme_merkmalContainer .bme_merkmal_select :selected').each(function() {
			if ($(this).val() != ''){
				if (ii > 0){
					bme_tmpMerkmale += '|';
				}
				
				bme_tmpMerkmale += $(this).closest("select").attr('data-id') + '_' + $(this).val();
				ii++;
			}
		});
		bme.eventTrackingFilter('merkmal', bme_tmpMerkmale);
		bme.query(bme.lastSearch);
	});
	
	$(".bme_input").bind('typeahead:select', function(ev, suggestion) {
//		console.log("trigger typeahead select");
		bme.showSearchWindow($(this).val())
	});
	
	$('body').on('keyup', '.bme_input.tt-input', function(e){
//		console.log("keyup trigger");
		//e.preventDefault();
		switch (e.keyCode) {
			case 13: // Enter
				clearTimeout(bme.ajaxTimer);
				history.replaceState(null, null, "navi.php?qs="+this.value);
				
				bme.eventTrackingSuche('enter', this.value);
				bme.showSearchWindow(this.value);
				break;
			// Esc?
			case 27:
				bme.hideSearchWindow();
				bme.eventTrackingAktion('close', 'ESC');
				return false;
				break;
			case 37: //Left
			case 38: //Up: 
			case 39: //Right
			case 40: //Down:
				break;
			default:
					clearTimeout(bme.ajaxTimer);
					var tmpData = this.value;
					bme.ajaxTimer = setTimeout(function() {
						//bme.eventTrackingSuche('live', $(this).val());
						bme.showSearchWindow(tmpData);
					}, bme.searchTimeout);
				break;
		}
	});	
	
	$('body').on('change', '#bme_filterManufacturer', function(e){
		e.preventDefault();
		var ii = 0;
		bme.manufacturer = "";
		$('#bme_filterManufacturer :selected').each(function() {
			if ($(this).val() != ''){
				if (ii > 0){
					bme.manufacturer += ',';
				}
			
				bme.manufacturer += $(this).val();
				ii++;
			}
		});
		bme.eventTrackingFilter('hersteller', bme.manufacturer);
		bme.showSearchWindow("bmeCachedSearch");
	});	
	
	$('body').on('click', '#bme_filterCatContainer .list-group-item', function(e){
		if ($(this).attr('data-id') != bme.category_filter_id) {
			bme.category_filter_id = $(this).attr('data-id');
			bme.eventTrackingFilter('kategorie', bme.category_filter_id);
			bme.showSearchWindow("bmeCachedSearch");
		}
		else {
			bme.category_filter_id = '';
			bme.eventTrackingFilter('reset', 'kategorie');
			bme.showSearchWindow("bmeCachedSearch");
		}
	});	
	
	$('body').on('click', '#bme_specialContainer button', function(e){
		if ($(this).hasClass('btn-primary')){
			$(this).removeClass('btn-primary');
		}
		else {
			$(this).addClass('btn-primary');
		}
		bme.eventTrackingFilter('special', $(this).attr("data-id"));
		bme.showSearchWindow("bmeCachedSearch");
	});	
	
	$('body').on('click', '#bme_reset_search, #bme_resetSearchInput', function(e){
		bme.eventTrackingFilter('reset', 'search');
		$(".bme_input").val("");
		bme.showSearchWindow("");
	});	
	
	$('body').on('click', '#bme_error', function(e){
		bme.showSearchWindow("bmeCachedSearch");
	});	
	
	$('body').on('click', '#bme_resetFilter, #bme_resetSearchFilter', function(e){
		bme.eventTrackingFilter('reset', 'search');
		bme.reset(bme.lastSearch);
	});	
	
	$('body').on('click', '.f_bme_container_manufacturer .f_value', function(e){
		bme.eventTrackingFilter('hersteller', $(this).attr('data-id'));
		$("#bme_filterManufacturer").val($(this).attr('data-id')).trigger("change");
	});	
	
	$('body').on('click', '.bme_articleCatPart', function(e){
		if ($(this).attr('data-id') != bme.category_filter_id) {
			bme.category_filter_id = $(this).attr('data-id');
			bme.showSearchWindow("bmeCachedSearch");
		}
		else {
			bme.category_filter_id = '';
			bme.showSearchWindow("bmeCachedSearch");
		}
	});	
	
	$('body').on('change', '.f_bme_sort', function(e){
		newSort = $(this).val();
		bme.eventTrackingFilter( 'sort', newSort);
		$('.bme.sort').val(newSort);
		if (newSort != bme.sort) {
			bme.sort = newSort;
			bme.showSearchWindow("bmeCachedSearch");
		}
	});
	/*
	$("body").on("keyup", function(e) {
		if(e.keyCode === 27) {
			bme.eventTrackingAktion('close', 'ESC');
			bme.hideSearchWindow();
		}
	});
	*/
	$("body").on("keyup", ".bme_priceFilterContainer input", function(e){
		priceHash = $('.bme_maxPrice').val() + '_' + $('.bme_minPrice').val() ;
		if (bme.current_filter_price != priceHash){
			bme.current_filter_price = priceHash;
			if(
					$('.bme_minPrice').val() == '' 
						|| 
					$('.bme_maxPrice').val() == '' 
						||
						parseFloat($('.bme_maxPrice').val().replace(/,/, '.')) > parseFloat($('.bme_minPrice').val().replace(/,/, '.'))
			)
				{
					bme.eventTrackingFilter('price', parseFloat($('.bme_maxPrice').val().replace(/,/, '.')) + "-"  + parseFloat($('.bme_minPrice').val().replace(/,/, '.')) );
					bme.showSearchWindow("bmeCachedSearch");
				}
		}
		
	});
	
	$('body').on('click', '#bme_loadMore', function(){
		bme.eventTrackingAktion('show more results', $("#bme_article_list li.list-group-item:visible:last").attr('data-pos'));
		bme.showSearchWindow("bmeCachedSearch", $("#bme_article_list li.list-group-item:visible:last").attr('data-pos'));
	});
	
	$('body').on('click', '#bme_scrollTop', function(){
		bme.scrollTop();
	});
	
	
	/* Trigger for reset filters.... */

	$('body').on('click', '.bme_priceFilterContainer .close', function(){
		$('.bme_minPrice').val('');
		$('.bme_maxPrice').val('');
		bme.eventTrackingFilter('reset', 'price');
		bme.showSearchWindow("bmeCachedSearch");
	});

	$('body').on('click', '#bme_filterManufacturerContainer .close', function(){
		bme.manufacturer = '';
		bme.eventTrackingFilter('reset', 'hersteller');
		$('#bme_filterManufacturer').val('');
		bme.showSearchWindow("bmeCachedSearch");
	});
	
	$('body').on('click', '#bme_specialContainer .close', function(){
		$('#bme_specialContainer button').each(function() {
			$(this).removeClass('btn-primary');
		});
		bme.eventTrackingFilter('reset', 'filter');
		bme.showSearchWindow("bmeCachedSearch");
	});
	
	$('body').on('click', '#bme_merkmalContainer .close', function(){
		$('#bme_merkmalContainer select').each(function() {
			$(this).val('');
		});
		bme.eventTrackingFilter('reset', 'merkmale');
		bme.showSearchWindow("bmeCachedSearch");
	});
	
	
	$('body').on('click', '#bme_filterCatContainer .close', function(){
		bme.category_filter_id = '';
		bme.eventTrackingFilter('reset','kategorie');
		bme.showSearchWindow("bmeCachedSearch");
	});
		
	$('body').on('click', '#bme_show_filter', function(e){
		bme.switch_filter();
	});
	
	$('body').on('click', '.bme_article_toCart', function(e){
		$.evo.basket().addToBasket($('<form id="test2"><input type="hidden" name="a" value="' + $(this).attr('data-id')+ '"><input type="hidden" name="anzahl" value="1"></form>')); 
	});
	
	$('body').on('click', '#bme_showActiveFilters .btn', function(e){
		bme_tmpType = $(this).data('type');
		if (bme_tmpType == 'minPrice'){
			$(".bme_minPrice").val("").keyup();
		}
		else if (bme_tmpType == 'maxPrice'){
			$(".bme_maxPrice").val("").keyup();
		}
		else if (bme_tmpType == 'special'){
			$('#bme_specialItemsContainer .' + $(this).data('id')).click();
		}
		else if (bme_tmpType == 'category'){
			$('#bme_filterCatContainer .list-group-item.active').click();
		}
		else if (bme_tmpType == 'merkmal'){
			$('.bme_merkmal_select option[value="' + $(this).data('id') + '"]').removeAttr("selected");
			$('.bme_merkmal_select').change();
		}
		else if (bme_tmpType == 'manufacturer'){
			$('#bme_filterManufacturer option[value="' + $(this).data('id') + '"]').removeAttr("selected");
			$('#bme_filterManufacturer').change();
		}
	});

	$('body').on('click', '#bme_searchQuery', function(e){
		bme.filterIsSet = true;
		$('.bme_input').val('').keyup();
	});
	
	
	
	
	/* SUGGEST Typeahead.... */
		
	bme.suggestData = new Bloodhound({
		datumTokenizer: Bloodhound.tokenizers.obj.whitespace('value'),
		queryTokenizer: Bloodhound.tokenizers.whitespace,
		remote: {
			//url: 'https://suche.bm-suche.de/bm-suche.de#%QUERY', 
			url: bme.AJAXURL + '#%QUERY',
			wildcard: '%QUERY', 
			transport: function(opts, onSuccess, onError){
				var url = opts.url.split("#")[0];
				var query = opts.url.split("#")[1];
				$.ajax({
					url: url,
					dataType: "json",
					data: {
						"suggest": query,
						"hash": $("#bme_results").attr("data-hash"),
						"jtlSetting": $("#bme_results").attr("data-jtl")
					},
					type: "POST",
					success: onSuccess,
					error: onError
				})
			} 
			, rateLimitWait: 50
		}
	});
	
	
	$(".bme_input").typeahead({
		hint: true,
		highlight: true
	}, {
		name: 'value'
		, source: bme.suggestData
	}).on('keyup', this, function (event) {
		if (event.keyCode == 13) {
			$('.bme_input.tt-input').typeahead('close');
		}
	});
	
	
}

bme.queryBykKategorie = function(kKategorie){
	if (!isNaN(kKategorie)){
		bme.category_filter_id = kKategorie;
		bme.filterIsSet = true;
		bme.showSearchWindow("bmeCachedSearch");
	}
}

bme.queryBykHersteller = function(kHersteller){
	if (!isNaN(kHersteller)){
		bme.queryBykHerstellerID = kHersteller;
		bme.filterIsSet = true;
		
		bme.showSearchWindow("bmeCachedSearch");
	}
}

bme.query = function(queryString, startPagination){
	bme_startSearch = true; 
	
	if( !$('body').hasClass('bme_searchPage')){
		bme_startSearch = false;
	}
	bme_searchCached = false;
	
	clearTimeout(bme.ajaxTimer);
	
	if (queryString == "bmeCachedSearch"){
		queryString = "";
	}
	if(queryString != ""){
		bme_startSearch = true;
	}
	
	bme.block_filters(true);
	startPagination = typeof startPagination !== 'undefined' ? startPagination : 0;
	
	
	var ii = 0;
	if (bme.queryBykHerstellerID > 0) {
		bme.manufacturer = bme.queryBykHerstellerID;
		bme.queryBykHerstellerID = 0;
		bme_startSearch = true;
	}
	else {
		bme.manufacturer = "";
		$('#bme_filterManufacturer :selected').each(function() {
			if ($(this).val() != ''){
				if (ii > 0){
					bme.manufacturer += ',';
				}
			
				bme.manufacturer += $(this).val();
				ii++;
				bme_startSearch = true;
			}
		});
	}
	
	var bme_merkmale = '';
	var ii = 0;
	$('#bme_merkmalContainer .bme_merkmal_select :selected').each(function() {
		if ($(this).val() != ''){
			if (ii > 0){
				bme_merkmale += '|';
			}
			
			bme_merkmale += $(this).closest("select").attr('data-id') + '_' + $(this).val();
			ii++;
			bme_startSearch = true;
		}
	});
	
	
	
	if(bme.category_filter_id == "-"){
		$("#bme_filterCatContainer .list-group-item").each(function(){
			if($(this).hasClass("active")){
				bme.category_filter_id = $(this).attr("data-id");
			}
		});
		if(bme.category_filter_id == "-"){
			bme.category_filter_id = "";
		}
	}
	
	
	var bme_special = '';
	var ii = 0;
	
	$('#bme_specialContainer .bme_specialItem').each(function() {
		if ($(this).hasClass('btn-primary')){
			if (ii > 0){
				bme_special += ',';
			}
			bme_special += $(this).attr('data-id');
			ii++;
			bme_startSearch = true;
		}
	});
	
	
	if($('.bme_priceFilterContainer .bme_minPrice').val() != ''){
		bme_startSearch = true;
	}

	if($('.bme_priceFilterContainer .bme_maxPrice').val() != ''){
		bme_startSearch = true;
	}
	
	if (startPagination == 0){
		newHash = queryString 
				+ bme.manufacturer 
				+ bme.category_filter_id 
				+ $('.bme_priceFilterContainer .bme_minPrice').val() 
				+ $('.bme_priceFilterContainer .bme_maxPrice').val()
				+ bme.sort
				+ bme_merkmale
				+ bme_special
				+ $("#bme_results").attr("data-jtl")
				+ $("#bme_results").attr("data-hash");
		
		if (newHash == bme.queryHash){
			bme_searchCached = true;
		}
		bme.queryHash = newHash;
	}
	
	if (bme_searchCached){
		bme.block_filters(false);
	}
	else if(bme_startSearch){
		bme.lastSearch = queryString;
		
		if (bme.xhr && bme.xhr.readystate != 4) {
			bme.xhr.abort();
		}
		
		if(bme.lastSearch == ""){
			newURL = "navi.php?qs=-";
		}
		else {
			newURL = "navi.php?qs=" + bme.lastSearch;
		}
		
		if(bme.manufacturer != ''){
			newURL +=  "&bme_mf=" + bme.manufacturer;
		}

		if(bme.category_filter_id != ''){
			newURL +=  "&bme_ct=" + bme.category_filter_id;
		}

		if($('.bme_priceFilterContainer .bme_minPrice').val() != ''){
			newURL +=  "&bme_min=" + $('.bme_priceFilterContainer .bme_minPrice').val();
		}

		if($('.bme_priceFilterContainer .bme_maxPrice').val() != ''){
			newURL +=  "&bme_max=" + $('.bme_priceFilterContainer .bme_maxPrice').val();
		}

		if(typeof(bme.sort) !== 'undefined' && bme.sort != ''){
			newURL +=  "&bme_so=" + bme.sort;
		}

		if(bme_merkmale != ''){
			newURL +=  "&bme_me=" + bme_merkmale;
		}

		if(bme_special != ''){
			newURL +=  "&bme_sp=" + bme_special;
		}
		bme.setHistoryURL(newURL);
		
		bme.xhr = $.ajax({
			type : 'POST',
			//url : 'https://suche.bm-suche.de/bm-suche.de',
			url: bme.AJAXURL, 
			//"//" + window.location.hostname + ".bm-suche.de/bme_search.php",
			data : {
				q : queryString
				, manufacturerID : bme.manufacturer
				, categoryID : bme.category_filter_id
				, minPrice : $('.bme_priceFilterContainer .bme_minPrice').val()
				, maxPrice : $('.bme_priceFilterContainer .bme_maxPrice').val()
				, sort : bme.sort
				, merkmale : bme_merkmale
				, special : bme_special
				, jtlSetting : $("#bme_results").attr("data-jtl")
				, hash : $("#bme_results").attr("data-hash")
				, startPagination : startPagination
			},
			dataType : 'json',
			cache : false,
			success : function(json) {
				if (startPagination == 0){
					bme.scrollTop();
				}
				
				if (bme.fill_template(json)) {
					bme.select2();
					bme.block_filters(false);
				}
			}
		});
	}
	else {
		bme.hideSearchWindow();
		bme.block_filters(false);
	}
}


bme.reset = function(queryString){
	bme.block_filters(true);
	bme.category_filter_id = "";
	bme.manufacturer = "";
	$('#bme_filterManufacturer select').each(function() {
		$(this).val('');
	});
	$('.bme_minPrice').val('');
	$('.bme_maxPrice').val('');
	$('#bme_merkmalContainer select').each(function() {
		$(this).val('');
	});
	
	if (bme.xhr && bme.xhr.readystate != 4) {
		bme.xhr.abort();
	}
	if (bme.queryHash != ""){
	bme.xhr = $.ajax({
		type : 'POST',
		//url : 'https://suche.bm-suche.de/bm-suche.de',
		url: bme.AJAXURL, 
		data : {
			q : queryString
			, sort : bme.sort
			, jtlSetting : $("#bme_results").attr("data-jtl")
			, hash : $("#bme_results").attr("data-hash")
		},
		dataType : 'json',
		cache : false,
		success : function(json) {
			bme.queryHash = "";
			if (bme.fill_template(json)) {
				bme.select2();
				bme.block_filters(false);
			}
		}
	});
	}
}

bme.fill_template = function(json){
	
	$('.select2-hidden-accessible').select2('close');
	
	$('#bme_hits .hits').html(json.hits);

	
	$('#bme_searchQuery .value').html(json.query);
	
	//ArticleTemplate
	var bme_article_item_tpl = $('#bme_article_template');
	if (json.count > 0) {
		for (i = 0; i < json.count; i++) {
		//$.each(json.items, function(i, result) {
		pos = Number(json.paginationStart);
		pos += Number(i);
		result = json.items[pos];
			
			bme_article_container_id = "#bme_article_item_" + pos;
			// Container not available => create new from
			// Template
			if (!$(bme_article_container_id).length) {
				$("#bme_article_list").append(
						bme_article_item_tpl.clone().attr('id',
								'bme_article_item_' + pos));
			}
			
			if ($(bme_article_container_id).length) {
				$(bme_article_container_id).removeClass("hide");
				
				
				if (!result.manufacturer || result.manufacturer.name == '--'){
					$(bme_article_container_id).find(".f_bme_container_manufacturer").hide();
				}
				else {
					$(bme_article_container_id).find(".f_bme_container_manufacturer").show();
					$(bme_article_container_id).find(".f_bme_container_manufacturer .f_value").text(result.manufacturer.name).attr("data-id", result.manufacturer.id);
					if (result.manufacturer.selected == 'Y'){
						$(bme_article_container_id).find(".f_bme_container_manufacturer").addClass('selected');
					}
					else {
						$(bme_article_container_id).find(".f_bme_container_manufacturer").removeClass('selected');
					}
				}
				
				
				if (result.vk == '--'){
					$(bme_article_container_id).find(".f_bme_container_price, .f_bme_container_vk, .f_bme_container_vpe").addClass('hide');
				}
				else {
					$(bme_article_container_id).find(".f_bme_container_price, .f_bme_container_vk").removeClass('hide');
					if (!result.vk || result.vk == ""){
						$(bme_article_container_id).find(".f_bme_container_vk .f_value").text('');
					}
					else {
						faktor = $("#bme_results").attr("data-cFaktor");
						faktor = parseFloat(faktor);
						if (!isNaN(faktor)){
							result.vk = Math.round(result.vk * faktor * 100) / 100;
						}
						$(bme_article_container_id).find(".f_bme_container_vk .f_value").text(result.vk);
						
						if (result.vpeUnit && result.vpeValue && !isNaN(result.vpeValue)){
							if (!isNaN(faktor)){
								result.vpeValue = Math.round(result.vpeValue * faktor * 100) / 100;
							}
							$(bme_article_container_id).find(".f_bme_container_vpe").removeClass('hide');
							$(bme_article_container_id).find(".f_bme_container_vpe .f_value").text(result.vpeValue);
							$(bme_article_container_id).find(".f_bme_container_vpe .f_unit").text(result.vpeUnit);
						}
						else {
							$(bme_article_container_id).find(".f_bme_container_vpe").addClass('hide');
							
						}
					}
				}
				
				if (result.artnr == '--'){
					$(bme_article_container_id).find(".f_bme_container_artnr").hide();
				}
				else {
					$(bme_article_container_id).find(".f_bme_container_artnr").show();
					$(bme_article_container_id).find(".f_bme_container_artnr .f_value").text(result.artnr);
				}
				
				if (result.han == '--'){
					$(bme_article_container_id).find(".bme_container_hartnr").hide();
				}
				else {
					$(bme_article_container_id).find(".bme_container_hartnr").show();
					$(bme_article_container_id).find(".bme_article_hartnr").html(result.han);
				}
				
				
				if (result.ean == '--'){
					$(bme_article_container_id).find(".f_bme_container_ean").hide();
				}
				else {
					$(bme_article_container_id).find(".f_bme_container_ean").show();
					$(bme_article_container_id).find(".f_bme_container_ean .f_value").text(result.ean);
				}
				
				if (result.isbn == '--'){
					$(bme_article_container_id).find(".f_bme_container_isbn").hide();
				}
				else {
					$(bme_article_container_id).find(".f_bme_container_isbn").show();
					$(bme_article_container_id).find(".f_bme_container_isbn .f_value").text(result.isbn);
				}
				
				if (result.asin == '--'){
					$(bme_article_container_id).find(".f_bme_container_asin").hide();
				}
				else {
					$(bme_article_container_id).find(".f_bme_container_asin").show();
					$(bme_article_container_id).find(".f_bme_container_asin .f_value").text(result.asin);
				}
				
				
				$(bme_article_container_id).find(".f_bme_article_link").attr('href', result.deeplink);
				$(bme_article_container_id).find(".f_bme_article_image").attr('src', result.image);
				
				$(bme_article_container_id).find(".bme_article_title").text(result.title)
				
				if (result.description == ""){
					$(bme_article_container_id).find('.bme_article_descriptionContainer').addClass('hide');
				}
				else {
					$(bme_article_container_id).find('.bme_article_description').html(result.description);
					$(bme_article_container_id).find('.bme_article_descriptionContainer').removeClass('hide');
				}
				$(bme_article_container_id).find(".f_bme_article_pos").text(result.pos+1);
				$(bme_article_container_id).attr("data-pos", result.pos);
				
				$(bme_article_container_id).find(".bme_article_toCart").attr("data-id", result.id);
				
				
		
				if(result.showFilter){
					$.each(result.showFilter, function(filterName, filterValue) {
						if (filterValue != 'N'){
							$(bme_article_container_id).find(".f_bme_showFilter_" + filterName).removeClass('hide');
						}
						else {
							$(bme_article_container_id).find(".f_bme_showFilter_" + filterName).addClass('hide');
						}
						
					});
				}
			};
			
			if (result.categories){
				$(bme_article_container_id).find('.bme_articleCatList').removeClass('hide').html();
				
				$(bme_article_container_id + " .bme_articleCatList").children().addClass("hide");
				
				$.each(result.categories, function(j, category) {
					categoryContainer = bme_article_container_id + " .bme_articleCatItem_" + (j+1);
					if (!$(categoryContainer).length) {
						newList = $('<ol/>', {
							"class": "bme_articleCatItem_" + (j+1) + " breadcrumb"
						});
						$(bme_article_container_id + " .bme_articleCatList").append(newList);
					} 
					
					if (categoryContainer.length) {
						
						$(categoryContainer).find(".bme_articleCatPart").remove();
					
						$(categoryContainer).removeClass("hide");
						$.each(category, function(k, categoryBread) {
							listItem = $('<li/>', {
								"class":  "bme_articleCatPart"
								, "data-id":  categoryBread.id
							});
							
							listItemElemClass = "";
							if (categoryBread.selected == 'Y'){
								listItemElemClass = "selected";
							}
							listItemElem = $('<a/>', {
								"html":  categoryBread.title
								, "data-id":  categoryBread.id
								, "class":  listItemElemClass
							});
							$(categoryContainer).append(listItem.append(listItemElem));
						});
					} else {
					}
						});
						}
			else {
				$(bme_article_container_id).find('.bme_articleCatList').addClass('hide');
			}
		};
		$('#bme_article_listEmpty').addClass('hide');
		$('#bme_error').hide();
	}
	else {
		$('#bme_article_listEmpty').removeClass('hide');
	}
	
	
	
	//ArticleTemplateEnd
	
	
	if (json.paginationStart == 0){
		$('#bme_article_list .bme_article_item').each(function(i){
			
			if (!json.items || !json.items[i]){
				$(this).addClass('hide');
			}
		});
		

		//active filters
		$('#bme_showActiveFilters, #bme_showActiveFilters .bme_activeFilter').addClass('hide');
		if(json.activeFilters && json.activeFilters.length != 0){
			$('#bme_showActiveFilters').removeClass('hide');
			$('#bme_showActiveFilters .merkmal, #bme_showActiveFilters .special').remove();
			
			$.each(json.activeFilters, function(key, result) {

				if (result.type == 'minPrice'){
					$('#bme_showActiveFilters .minPrice').attr("data-id", result.id).attr("data-type", result.type).removeClass('hide').find('.value').html(result.name);
				}
				else if (result.type == 'maxPrice'){
					$('#bme_showActiveFilters .maxPrice').attr("data-id", result.id).attr("data-type", result.type).removeClass('hide').find('.value').html(result.name);
				}
				else if (result.type == 'category'){
					$('#bme_showActiveFilters .category').attr("data-id", result.id).attr("data-type", result.type).removeClass('hide').find('.value').html(result.name);
				}
				else if (result.type == 'merkmal' || result.type == 'manufacturer'){
					tmpTemplate = $('#bme_showActiveFilters .' + result.type + '_tpl').clone();
					tmpTemplate.removeClass(result.type + '_tpl hide');
					tmpTemplate.attr("data-id", result.id).attr("data-type", result.type);
					tmpTemplate.find('.f_value').html(result.name);
					tmpTemplate.appendTo('.activeFilterTarget');
				}
				else if (result.type == 'special'){
					$('#bme_showActiveFilters .special_' + result.id).attr("data-id", result.id).attr("data-type", result.type).removeClass( 'hide');
				}
			});
		}
		
		if (json.settings.manufacturerType == 'multiple') {
			$('#bme_filterManufacturer').attr("multiple", "multiple");
		}
		if (json.settings.showCart == 'Y') {
			$('.bme_article_toCart').removeClass('hide');
		}
		else {
			$('.bme_article_toCart').addClass('hide');
		}
		
		if (json.settings.showPriceFilter == 'Y') {
			$('.bme_priceFilterContainer').removeClass('hide');
		}
		else {
			$('.bme_priceFilterContainer').addClass('hide');
		}
		//ManufacturerFilter
		$('#bme_filterManufacturer').children().remove().end().attr('data-placeholder', $('#bme_filterManufacturer').attr("data-first-elem")).append('<option value=""></option>') ;
		
		if(json.manufacturer){
			$('#bme_filterManufacturerContainer').removeClass('hide');
			
			
			$.each(json.manufacturer, function(i, result) {
				if(result.selected == 'Y') {
					$('#bme_filterManufacturer').append($('<option>', {
						value: result.id,
						selected: 'true',
						text: result.name + " (" + result.count + ")"
					}));
				}
				else {
					$('#bme_filterManufacturer').append($('<option>', {
						value: result.id,
						text: result.name + " (" + result.count + ")"
					}));
				}
			});
			
			/*
			if (!isNaN(bme.manufacturer_filter_id) && $("#bme_filterManufacturer option[value='" + bme.manufacturer_filter_id + "']").length > 0){
				$('#bme_filterManufacturer').val(bme.manufacturer_filter_id);
			}
			else {
				$('#bme_filterManufacturer').val("");
			}
			*/
		
		}
		else {
			$('#bme_filterManufacturerContainer').addClass('hide');
		}
		
		//Categories
		/*
		if (json.catHTML != ""){
			$('#bme_filterCatContainer').removeClass('hide');
			$('#bme_filterCatList').html(json.catHTML);
		}
		else {
			$('#bme_filterCatContainer').addClass('hide');
		}*/
		
		if (json.catARR != ""){
			$('#bme_filterCatContainer').removeClass('hide');
			$('#bme_filterCatContainer .list-group').html('');
			$.each(json.catARR, function (i, result){
				if (result.selected == 'Y'){
					newCatItem = $('<a class="list-group-item active lvl_' + result.lvl + '" data-id="' + result.id + '">' + result.name + '</a>');
				}
				else {
					newCatItem = $('<a class="list-group-item lvl_' + result.lvl + '" data-id="' + result.id + '">' + result.name + '</a>');
				}
				$('#bme_filterCatContainer .list-group').append(newCatItem);
			});
		}
		else {
			$('#bme_filterCatContainer').addClass('hide');
		}
		
		
		
		$('#bme_merkmalContainer .panel-body').html('');
		
		if(json.merkmale){
			var bme_showMerkmale = false;
			$.each(json.merkmale, function(i, result){
				if (result.type == 'selectsingle' || result.type == 'selectmulti') {
					bme_showMerkmale = true;
					
					resultContainerID = 'bme_merkmal_' + result.id;
					tmpl = $('#bme_merkmal_selectbox_template');
					$('#bme_merkmalContainer .panel-body').append(
						tmpl.clone().attr('id', resultContainerID)
					);
					$('#' + resultContainerID + ' .bme_merkmal_select').attr('data-id', result.id);
					
					if (result.type == 'selectmulti') {
						$('#' + resultContainerID + ' .bme_merkmal_select').attr("multiple", "multiple");
					}
					
					$('#' + resultContainerID + ' .bme_merkmal_select').attr('data-placeholder', result.title).append($('<option>', {
						value: ''
					}));
					selectedOption = '';
					$.each(result.values, function(j, result2){
						if (result2.selected == 'Y') {
							$('#' + resultContainerID + ' .bme_merkmal_select').append($('<option>', {
								value: result2.id,
								selected: true,
								text: result2.title + " (" + result2.count + ")"
							}));
							}
						else {
							$('#' + resultContainerID + ' .bme_merkmal_select').append($('<option>', {
								value: result2.id,
								text: result2.title + " (" + result2.count + ")"
							}));
						}
					});
							
					
				}
			});
			if (bme_showMerkmale){
				$('#bme_merkmalContainer, #bme_merkmalContainer .panel-body .bme_merkmal').removeClass('hide');
			}
		}
		else {
			$('#bme_merkmalContainer').addClass('hide');
			$('#bme_merkmalContainer panel-body').html('');
			$('#bme_merkmalContainer select').each(function() {
				$(this).val('');
			});
		}
		
		if(json.special){
			bme_showSpecials = false;
			$.each($('#bme_specialContainer .bme_specialItem'), function(i, result){
				bme_attrName = $(this).attr('data-id');
				if (json.special[bme_attrName] && json.special[bme_attrName].selected == 'Y'){
					$(this).removeClass('hide').addClass('btn-primary');
					bme_showSpecials = true;
				}
				else if (json.special[bme_attrName] && json.special[bme_attrName].selected == 'N'){
					$(this).removeClass('hide btn-primary');
					bme_showSpecials = true;
				}
				else {
					$(this).addClass('hide');
				}
			});
			if(bme_showSpecials){
				$('#bme_specialContainer').removeClass('hide');
			}
			else {
				$('#bme_specialContainer').addClass('hide');
			}
		}
		else {
			$('#bme_specialContainer').addClass('hide');
		}
		
		
		
		/* Reset Filters..... */
		showResetAll = false;
		
		if ($('.bme_minPrice').val() != '' || $('.bme_maxPrice').val() != '') {
			$('.bme_priceFilterContainer .close').removeClass('hide');
			showResetAll = true;
		}
		else {
			$('.bme_priceFilterContainer .close').addClass('hide');
		}
		
		
		if ($('#bme_filterManufacturer :selected').length){
			showResetAll = true;
			$('#bme_filterManufacturerContainer .close').removeClass('hide');		
		}
		else {
			$('#bme_filterManufacturerContainer .close').addClass('hide');
		}		
		
		if (bme.category_filter_id != '' && bme.category_filter_id != '') {
			$('#bme_filterCatContainer .close').removeClass('hide');
			showResetAll = true;
		}
		else {
			$('#bme_filterCatContainer .close').addClass('hide');
		}
		
		if ($('#bme_specialContainer button.btn-primary').length) {
			$('#bme_specialContainer .close').removeClass('hide');	
			showResetAll = true;
		}
		else {
			$('#bme_specialContainer .close').addClass('hide');
		}
		
		
		showMerkmalClose = false;
		$('#bme_merkmalContainer .bme_merkmal_select').each(function() {
			if ($(this).val() != '' && $(this).val() != ''){
				showMerkmalClose = true;
				showResetAll = true;
			}
		});
		if (showMerkmalClose){
			$('#bme_merkmalContainer .close').removeClass('hide');
		}
		else {
			$('#bme_merkmalContainer .close').addClass('hide');
		}
		
		if(showResetAll){
			$('#bme.resetFilter').removeClass('hide');
		}
		else {
			$('#bme.resetFilter').addClass('hide');
		}
		
		/* Reset Filters..... */
		
		
	}
	
	//Show Hide reload button
	currentPos = parseInt($("#bme_article_list li.list-group-item:visible:last").attr('data-pos')) + 1;

	if (json.hits > currentPos && currentPos < 500){
		$('#bme_loadMore').removeClass('hide');
		$('#bme_loadMore .value').html(json.remaining);
	}
	else {
		$('#bme_loadMore').addClass('hide');
	}
	
	if(json.hits > 10){
		$('#bme_scrollTop').show();
	}
	else {
		$('#bme_scrollTop').hide();
	}
	if (json.paginationStart == 0) {
		bme.scrollTop();
	}
	
	
	return true;
	
}

window.onpopstate = function(e){
    if(e.state !== null) {
//    	console.log("popstate");
	location.reload();    
    }
    else {
//    		console.log("no popstate");
    }
}
    

	
bme.setHistoryURL = function(newURL){
	if (bme.startURL == ''){
//		console.log("set start URL: " + window.location.href);
		bme.startURL = window.location.href;
	}
	if (newURL == ''){
		newURL = bme.startURL;
	}
	window.historyInitiated = true;
	if (bme.historyReplaced){
		history.replaceState(null, null, encodeURI(newURL));
	}
	else {
		history.pushState(null, null, encodeURI(newURL));
		bme.historyReplaced = true;
	}
	bme.pageTrackingSuche(newURL)
	
}

bme.select2 = function(){
	$("#bme_filterManufacturer").select2({
		minimumResultsForSearch: 5
		, width: '100%'
		//allow_single_deselect: true
		//, width: '100%'
		//, disable_search_threshold: 5
		}
	).trigger("select2:select");
	
	$('.panel-body .bme_merkmal_select').select2({
			minimumResultsForSearch: 5
			, width: '100%'
	}).trigger("select2:select");
	
	/*
	$("#bme.sort").chosen({
		disable_search: true
		}
	);
	$("#bme.sort").trigger("chosen:updated");
	*/
}

bme.switch_filter = function(){
	if ( $('#bme_show_filter').hasClass('active')) {
		$('#bme_show_filter').removeClass('active');
		$('#bme_results .columnleft').addClass('hidden-sm hidden-xs');
		$('#bme_article_listEmpty, #bme_article_list, #bme_article_footer').removeClass('hidden-sm hidden-xs');
		$('.bme_filter_showFilter').removeClass('hide');
		$('.bme_filter_showResults').addClass('hide');
	}
	else {
		$('#bme_show_filter').addClass('active');
		$('#bme_results .columnleft').show();
		$('#bme_results .columnleft').removeClass('hidden-sm hidden-xs');
		$('#bme_article_listEmpty, #bme_article_list, #bme_article_footer').addClass('hidden-sm hidden-xs');
		$('.bme_filter_showFilter').addClass('hide');
		$('.bme_filter_showResults').removeClass('hide');
	}
}




bme.showSearchWindow = function(queryString, startPagination){
	if (queryString == null){
		queryString = '';
	}
	if (queryString == "bmeCachedSearch"){
		queryString = bme.lastSearch;
	}
	//console.log("query:"+queryString);

	if (1 || queryString.length > 0 || bme.filterIsSet || $("body.bme_searchPage").length ){
		startPagination = typeof startPagination !== 'undefined' ? startPagination : 0;

		if (!$("body").hasClass("bme_opened")){
			bme.eventTrackingAktion('opened', 'search window');	

			$("body").addClass("bme_opened");
			$(document).off('click', '#bme_container');
			//$('#bme_container').removeClass("bme_opened").css("opacity", "0").addClass("bme_opened").animate({opacity: 1}, 500);
			$('#bme_container').addClass("bme_opened");
			if (!bme.initialised){
				bme.init();
			}
		}
		bme.query(queryString, startPagination);
		//$('.bme_input').focus();
	}
	else {
		//bme.hideSearchWindow();
	}

}

bme.hideSearchWindow = function(){
	if( !$('body').hasClass('bme_searchPage')){
		$("body").removeClass("bme_opened");
		$(document).off('click', '#bme_container');
		$('#bme_container').removeClass("bme_opened").css("opacity", "0");
		bme.setHistoryURL('');
	}
}

bme.scrollTop = function() {
	$('html,body').animate({ scrollTop: 0 }, "slow");
	return false;
}