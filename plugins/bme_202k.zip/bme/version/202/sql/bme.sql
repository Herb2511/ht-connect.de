CREATE TABLE IF NOT EXISTS `xplugin_bme_update_kArticle` (
  `kArtikel` int(11) unsigned NOT NULL,
  PRIMARY KEY (`kArtikel`)
);

CREATE TABLE IF NOT EXISTS `xplugin_bme_delete_kArticle` (
  `kArtikel` int(11) unsigned NOT NULL,
  PRIMARY KEY (`kArtikel`)
);